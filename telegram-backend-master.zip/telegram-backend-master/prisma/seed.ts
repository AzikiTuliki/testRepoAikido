import { PrismaClient, WorkFormat } from '@prisma/client';
import * as bcrypt from 'bcrypt';

const prisma = new PrismaClient();

async function main() {
  const hashedPassword = await bcrypt.hash('admin123', 10);

  // 1. Create RoboBot
  const roboBot = await prisma.bot.upsert({
    where: { slug: 'robo_bot' },
    update: {
      token: process.env.ROBOT_TOKEN || 'YOUR_BOT_TOKEN',
      name: 'RoboBot System',
    },
    create: {
      name: 'RoboBot System',
      slug: 'robo_bot',
      token: process.env.ROBOT_TOKEN || 'YOUR_BOT_TOKEN',
    },
  });

  // 1.1 Create MadenietBot
  const madenietBot = await prisma.bot.upsert({
    where: { slug: 'madeniet_bot' },
    update: {
      token: process.env.MADENIET_TOKEN || 'YOUR_MADENIET_TOKEN',
      name: 'Madeniet Education Bot',
    },
    create: {
      name: 'Madeniet Education Bot',
      slug: 'madeniet_bot',
      token: process.env.MADENIET_TOKEN || 'YOUR_MADENIET_TOKEN',
    },
  });

  // 2. Create a single Super-admin
  await prisma.user.upsert({
    where: { email: 'admin@gmail.com' },
    update: { botId: null },
    create: {
      email: 'admin@gmail.com',
      password: hashedPassword,
      name: 'Super Administrator',
      botId: null,
    },
  });

  // 3. Create Contests
  const contests = [
    {
      id: 'contest-1',
      name: 'RoboStart-қа қатысу',
      description: `*ROBOSTART РОБОТОТЕХНИКА ОЛИМПИАДАСЫ* 🤖\n\n*Қатысушылар:* 4–15 жас аралығындағы оқушылар.\n*Бағыттар:* Junior (4–6), Beginner (7–9), Intermediate (10–12), Advanced (13–15).\n*Номинациялар:* Кедергіден өтетін робот, Ақылды робот жобасы, Инновациялық стартап жоба.\n*Жұмыс форматы:* Жобаның жұмысын көрсететін видео (YouTube немесе Google Drive сілтемесі).\n*Мақсаты:* Балалардың инженерлік ойлауын, шығармашылық қабілетін және робототехникаға қызығушылығын дамыту.`,
      order: 1,
      workFormat: WorkFormat.VIDEO,
      botId: roboBot.id,
    },
    {
      id: 'contest-madeniet-1',
      name: 'Балапан бояулар әлеміне қатысу',
      description: `*«MADENIET_EDUCATION» республикалық журналы шақырады* 📘\n\n*Тақырып:* “ШУАҚТЫ КҮНДЕР”, “ӘЗ НАУРЫЗЫМ- ЖАҢА ЖЫЛЫМ”.\n\nҚолөнер, бейнелеу өнері, фотоөнері жұмыстарын жолдайсыз.`,
      order: 1,
      workFormat: WorkFormat.IMAGE,
      botId: madenietBot.id,
    },
  ];

  for (const contest of contests) {
    await prisma.contest.upsert({
      where: { id: contest.id },
      update: contest,
      create: contest,
    });
  }

  const otherBots = await prisma.bot.findMany({
    where: {
      slug: { notIn: ['robo_bot', 'madeniet_bot'] },
    },
  });

  for (const bot of otherBots) {
    await prisma.submission.deleteMany({ where: { botId: bot.id } });
    await prisma.contest.deleteMany({ where: { botId: bot.id } });
    await prisma.user.deleteMany({ where: { botId: bot.id } });
    await prisma.bot.delete({ where: { id: bot.id } });
  }

  console.log('Seed completed successfully.');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
