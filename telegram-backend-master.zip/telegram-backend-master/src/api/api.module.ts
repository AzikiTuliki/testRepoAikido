import { Module } from '@nestjs/common';
import { DatabaseModule } from '../database/database.module';
import { BotModule } from '../bot/bot.module';
import { ContestController } from './controllers/contest.controller';
import { SubmissionController } from './controllers/submission.controller';
import { BotController } from './controllers/bot.controller';

@Module({
  imports: [DatabaseModule, BotModule],
  controllers: [ContestController, SubmissionController, BotController],
})
export class ApiModule {}
