import {
  Controller,
  Get,
  Post,
  Body,
  Param,
  Put,
  Delete,
  UseGuards,
  Req,
  ForbiddenException,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiParam,
  ApiBearerAuth,
} from '@nestjs/swagger';
import { CreateBotDto, UpdateBotDto } from '../dtos/bot.dto';
import { PrismaService } from '../../database/prisma.service';
import { JwtAuthGuard } from '../../auth/guards/jwt-auth.guard';
import { AuthenticatedUser } from '../../auth/strategies/jwt.strategy';
import { BotRegistryService } from '../../bot/services/bot-registry.service';

@ApiTags('Bots')
@ApiBearerAuth()
@Controller('api/bots')
@UseGuards(JwtAuthGuard)
export class BotController {
  constructor(
    private readonly prisma: PrismaService,
    private readonly botRegistry: BotRegistryService,
  ) {}

  @Get()
  @ApiOperation({ summary: 'Get all bots' })
  @ApiResponse({ status: 200, description: 'Return all bots' })
  async findAll(@Req() req: any) {
    const user = req.user as AuthenticatedUser;

    // Bot-scoped users only see their own bot
    const where = user.botId ? { id: user.botId } : {};

    return this.prisma.bot.findMany({
      where,
      include: { _count: { select: { contests: true } } },
    });
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get a bot by ID' })
  @ApiParam({ name: 'id', description: 'Bot ID' })
  @ApiResponse({ status: 200, description: 'Return the bot' })
  @ApiResponse({ status: 403, description: 'Forbidden' })
  @ApiResponse({ status: 404, description: 'Not Found' })
  async findOne(@Param('id') id: string, @Req() req: any) {
    const user = req.user as AuthenticatedUser;

    if (user.botId && user.botId !== id) {
      throw new ForbiddenException('Access denied');
    }

    return this.prisma.bot.findUnique({
      where: { id },
      include: { _count: { select: { contests: true } } },
    });
  }

  @Post()
  @ApiOperation({ summary: 'Create a new bot (Super-admin only)' })
  @ApiResponse({ status: 201, description: 'The bot has been successfully created' })
  @ApiResponse({ status: 403, description: 'Forbidden' })
  async create(@Body() data: CreateBotDto, @Req() req: any) {
    const user = req.user as AuthenticatedUser;

    // Only super-admins can create bots
    if (user.botId) {
      throw new ForbiddenException('Only super-admins can create bots');
    }

    return this.prisma.bot.create({ data });
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update a bot' })
  @ApiParam({ name: 'id', description: 'Bot ID' })
  @ApiResponse({ status: 200, description: 'The bot has been successfully updated' })
  @ApiResponse({ status: 403, description: 'Forbidden' })
  async update(
    @Param('id') id: string,
    @Body() body: UpdateBotDto,
    @Req() req: any,
  ) {
    const user = req.user as AuthenticatedUser;

    if (user.botId && user.botId !== id) {
      throw new ForbiddenException('Access denied');
    }

    // Robustly extract only valid update fields
    const updateData: {
      name?: string;
      token?: string;
      slug?: string;
      isActive?: boolean;
      messages?: any;
    } = {};

    if (body.name !== undefined) updateData.name = body.name;
    if (body.token !== undefined) updateData.token = body.token;
    if (body.slug !== undefined) updateData.slug = body.slug;
    if (body.isActive !== undefined) {
      updateData.isActive =
        typeof body.isActive === 'string'
          ? body.isActive === 'true'
          : !!body.isActive;
    }
    if (body.messages !== undefined) updateData.messages = body.messages;

    const updatedBot = await this.prisma.bot.update({
      where: { id },
      data: updateData,
    });

    // Refresh bot registry cache to apply message changes immediately
    await this.botRegistry.refreshCache();

    return updatedBot;
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete a bot (Super-admin only)' })
  @ApiParam({ name: 'id', description: 'Bot ID' })
  @ApiResponse({ status: 200, description: 'The bot has been successfully deleted' })
  @ApiResponse({ status: 403, description: 'Forbidden' })
  async delete(@Param('id') id: string, @Req() req: any) {
    const user = req.user as AuthenticatedUser;

    // Only super-admins can delete bots
    if (user.botId) {
      throw new ForbiddenException('Only super-admins can delete bots');
    }

    return this.prisma.bot.delete({ where: { id } });
  }
}
