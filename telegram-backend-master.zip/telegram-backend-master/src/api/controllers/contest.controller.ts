import {
  Controller,
  Get,
  Post,
  Body,
  Param,
  Put,
  Delete,
  Query,
  UseGuards,
  Req,
  ForbiddenException,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiParam,
  ApiQuery,
  ApiBearerAuth,
} from '@nestjs/swagger';
import { CreateContestDto, UpdateContestDto } from '../dtos/contest.dto';
import { ContestRepository } from '../../database/repositories/contest.repository';
import { WorkFormat } from '@prisma/client';
import { JwtAuthGuard } from '../../auth/guards/jwt-auth.guard';
import { AuthenticatedUser } from '../../auth/strategies/jwt.strategy';
import { MinioService } from '../../storage/minio.service';
import { PrismaService } from '../../database/prisma.service';

@ApiTags('Contests')
@ApiBearerAuth()
@Controller('api/contests')
@UseGuards(JwtAuthGuard)
export class ContestController {
  constructor(
    private readonly contestRepository: ContestRepository,
    private readonly minioService: MinioService,
    private readonly prisma: PrismaService,
  ) {}

  @Get()
  @ApiOperation({ summary: 'Get all contests' })
  @ApiQuery({ name: 'botId', required: false, description: 'Filter by Bot ID' })
  @ApiResponse({ status: 200, description: 'Return all contests' })
  async findAll(@Query('botId') botId: string | undefined, @Req() req: any) {
    const user = req.user as AuthenticatedUser;

    // Bot-scoped users always see only their bot's contests
    const effectiveBotId = user.botId || botId;
    return this.contestRepository.findAll(effectiveBotId);
  }

  @Post()
  @ApiOperation({ summary: 'Create a new contest' })
  @ApiResponse({ status: 201, description: 'The contest has been successfully created' })
  @ApiResponse({ status: 403, description: 'Forbidden' })
  async create(
    @Body()
    body: CreateContestDto,
    @Req() req: any,
  ) {
    const user = req.user as AuthenticatedUser;

    // Bot-scoped users can only create contests for their own bot
    if (user.botId && body.botId && body.botId !== user.botId) {
      throw new ForbiddenException('Access denied');
    }

    // Robustly extract only valid fields
    const createData: {
      name: string;
      description?: string;
      isActive?: boolean;
      order?: number;
      workFormat?: WorkFormat;
      botId: string;
    } = {
      name: body.name,
      botId: user.botId || body.botId,
    };

    if (body.description !== undefined)
      createData.description = body.description;
    if (body.isActive !== undefined) {
      createData.isActive =
        typeof body.isActive === 'string'
          ? body.isActive === 'true'
          : !!body.isActive;
    }
    if (body.order !== undefined) {
      createData.order =
        typeof body.order === 'string' ? parseInt(body.order, 10) : body.order;
    }
    if (body.workFormat !== undefined) createData.workFormat = body.workFormat;

    if (!createData.name) {
      throw new ForbiddenException('Name is required');
    }

    if (!createData.botId) {
      throw new ForbiddenException('Bot ID is required');
    }

    return this.contestRepository.create(createData);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get a contest by ID' })
  @ApiParam({ name: 'id', description: 'Contest ID' })
  @ApiResponse({ status: 200, description: 'Return the contest' })
  @ApiResponse({ status: 403, description: 'Forbidden' })
  @ApiResponse({ status: 404, description: 'Not Found' })
  async findOne(@Param('id') id: string, @Req() req: any) {
    const user = req.user as AuthenticatedUser;
    const contest = await this.contestRepository.findById(id);

    if (user.botId && contest && contest.botId !== user.botId) {
      throw new ForbiddenException('Access denied');
    }

    return contest;
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update a contest' })
  @ApiParam({ name: 'id', description: 'Contest ID' })
  @ApiResponse({ status: 200, description: 'The contest has been successfully updated' })
  @ApiResponse({ status: 403, description: 'Forbidden' })
  @ApiResponse({ status: 404, description: 'Not Found' })
  async update(
    @Param('id') id: string,
    @Body()
    body: UpdateContestDto,
    @Req() req: any,
  ) {
    const user = req.user as AuthenticatedUser;

    // Verify ownership
    const contest = await this.contestRepository.findById(id);
    if (!contest) {
      throw new ForbiddenException('Contest not found');
    }

    if (user.botId && contest.botId !== user.botId) {
      throw new ForbiddenException('Access denied');
    }

    // Bot-scoped users cannot reassign contest to another bot
    if (user.botId && body.botId && body.botId !== user.botId) {
      throw new ForbiddenException('Cannot reassign contest to another bot');
    }

    // Robustly extract only valid update fields
    const updateData: {
      name?: string;
      description?: string;
      isActive?: boolean;
      order?: number;
      workFormat?: WorkFormat;
      botId?: string;
    } = {};

    if (body.name !== undefined) updateData.name = body.name;
    if (body.description !== undefined)
      updateData.description = body.description;
    if (body.isActive !== undefined) {
      updateData.isActive =
        typeof body.isActive === 'string'
          ? body.isActive === 'true'
          : !!body.isActive;
    }
    if (body.order !== undefined) {
      updateData.order =
        typeof body.order === 'string' ? parseInt(body.order, 10) : body.order;
    }
    if (body.workFormat !== undefined) updateData.workFormat = body.workFormat;
    if (body.botId !== undefined) updateData.botId = body.botId;

    return this.contestRepository.update(id, updateData);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete a contest' })
  @ApiParam({ name: 'id', description: 'Contest ID' })
  @ApiResponse({ status: 200, description: 'The contest has been successfully deleted' })
  @ApiResponse({ status: 403, description: 'Forbidden' })
  @ApiResponse({ status: 404, description: 'Not Found' })
  async delete(@Param('id') id: string, @Req() req: any) {
    const user = req.user as AuthenticatedUser;

    // Verify ownership
    const contest = await this.contestRepository.findById(id);
    if (!contest) {
      throw new ForbiddenException('Contest not found');
    }

    if (user.botId && contest.botId !== user.botId) {
      throw new ForbiddenException('Access denied');
    }

    // 1. Find all submissions for this contest to get file keys
    const submissions = await this.prisma.submission.findMany({
      where: { contestId: id },
      select: { workFileId: true, paymentFileId: true },
    });

    const fileKeysToDelete: string[] = [];
    submissions.forEach((s) => {
      if (s.workFileId) fileKeysToDelete.push(s.workFileId);
      if (s.paymentFileId) fileKeysToDelete.push(s.paymentFileId);
    });

    // 2. Delete files from MinIO in batches (Max 1000 per request for S3)
    if (fileKeysToDelete.length > 0) {
      // Small optimization: unique keys only
      const uniqueKeys = [...new Set(fileKeysToDelete)];
      await this.minioService.deleteMultipleFiles(uniqueKeys);
    }

    // 3. Delete submissions and contest in a transaction
    return this.prisma.$transaction(async (tx) => {
      await tx.submission.deleteMany({
        where: { contestId: id },
      });

      return tx.contest.delete({
        where: { id },
      });
    });
  }
}
