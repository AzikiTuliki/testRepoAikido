import {
  Controller,
  Get,
  Query,
  Param,
  Delete,
  Post,
  Put,
  Body,
  UseInterceptors,
  UploadedFile,
  NotFoundException,
  UseGuards,
  Req,
  ForbiddenException,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiParam,
  ApiQuery,
  ApiBearerAuth,
  ApiConsumes,
  ApiBody,
} from '@nestjs/swagger';
import {
  UpdateSubmissionDto,
  FindAllSubmissionsDto,
} from '../dtos/submission.dto';
import { FileInterceptor } from '@nestjs/platform-express';
import { SubmissionRepository } from '../../database/repositories/submission.repository';
import { MinioService } from '../../storage/minio.service';
import { BotService } from '../../bot/services/bot.service';
import { JwtAuthGuard } from '../../auth/guards/jwt-auth.guard';
import { AuthenticatedUser } from '../../auth/strategies/jwt.strategy';
import { I18nService } from '../../bot/services/i18n.service';

@ApiTags('Submissions')
@ApiBearerAuth()
@Controller('api/submissions')
@UseGuards(JwtAuthGuard)
export class SubmissionController {
  constructor(
    private readonly submissionRepository: SubmissionRepository,
    private readonly minioService: MinioService,
    private readonly botService: BotService,
    private readonly i18nService: I18nService,
  ) {}

  @Get('file-url')
  @ApiOperation({ summary: 'Generate a presigned URL for a file' })
  @ApiQuery({ name: 'key', description: 'File key (MinIO/S3 path)' })
  @ApiResponse({ status: 200, description: 'Return presigned URL' })
  async getFileUrl(@Query('key') key: string) {
    const url = await this.minioService.generatePresignedUrl(key);
    return { url };
  }

  @Post(':id/certificates')
  @UseInterceptors(FileInterceptor('file'))
  @ApiOperation({ summary: 'Upload and send a certificate to a user via Telegram' })
  @ApiParam({ name: 'id', description: 'Submission ID' })
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        file: {
          type: 'string',
          format: 'binary',
        },
      },
    },
  })
  @ApiResponse({ status: 201, description: 'Certificate sent successfully' })
  @ApiResponse({ status: 403, description: 'Forbidden' })
  @ApiResponse({ status: 404, description: 'Submission not found' })
  async uploadCertificate(
    @Param('id') id: string,
    @UploadedFile() file: Express.Multer.File,
    @Req() req: any,
  ) {
    const user = req.user as AuthenticatedUser;
    const submission = await this.submissionRepository.findById(id);

    if (!submission) {
      throw new NotFoundException('Submission not found');
    }

    // Bot-scoped users can only send certificates for their bot's submissions
    if (user.botId && submission.botId !== user.botId) {
      throw new ForbiddenException('Access denied');
    }

    if (!file) {
      throw new Error('No file uploaded');
    }

    // Send the file to the user via Telegram
    await this.botService.sendDocument(
      submission.telegramUserId,
      file.buffer,
      file.originalname,
      `Сіздің байқауға қатысып, жүлделі орын алғаныңыз үшін берілетін сертификатыңыз! 🎉`,
      submission.contest?.bot?.slug,
    );

    // Mark as sent in database
    await this.submissionRepository.update(id, { isCertificateSent: true });

    return { success: true };
  }

  @Get()
  @ApiOperation({ summary: 'Get all submissions' })
  @ApiResponse({ status: 200, description: 'Return all submissions' })
  async findAll(@Query() query: FindAllSubmissionsDto, @Req() req: any) {
    const user = req.user as AuthenticatedUser;
    const skip = query.skip ? Number(query.skip) : 0;
    const take = query.take ? Number(query.take) : 50;

    // Bot-scoped users always see only their bot's submissions
    const effectiveBotId = user.botId || query.botId;

    return this.submissionRepository.findAll({
      ...query,
      skip,
      take,
      botId: effectiveBotId,
    });
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get a submission by ID' })
  @ApiParam({ name: 'id', description: 'Submission ID' })
  @ApiResponse({ status: 200, description: 'Return the submission' })
  @ApiResponse({ status: 403, description: 'Forbidden' })
  @ApiResponse({ status: 404, description: 'Not Found' })
  async findOne(@Param('id') id: string, @Req() req: any) {
    const user = req.user as AuthenticatedUser;
    const submission = await this.submissionRepository.findById(id);

    if (user.botId && submission && submission.botId !== user.botId) {
      throw new ForbiddenException('Access denied');
    }

    return submission;
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete a submission' })
  @ApiParam({ name: 'id', description: 'Submission ID' })
  @ApiResponse({ status: 200, description: 'The submission has been successfully deleted' })
  @ApiResponse({ status: 403, description: 'Forbidden' })
  @ApiResponse({ status: 404, description: 'Not Found' })
  async delete(@Param('id') id: string, @Req() req: any) {
    const user = req.user as AuthenticatedUser;

    // Verify ownership and get file keys
    const submission = await this.submissionRepository.findById(id);
    if (!submission) {
      throw new NotFoundException('Submission not found');
    }

    if (user.botId && submission.botId !== user.botId) {
      throw new ForbiddenException('Access denied');
    }

    // 1. Collect file keys to delete
    const fileKeys: string[] = [];
    if (submission.workFileId) fileKeys.push(submission.workFileId);
    if (submission.paymentFileId) fileKeys.push(submission.paymentFileId);

    // 2. Delete files from MinIO
    if (fileKeys.length > 0) {
      await this.minioService.deleteMultipleFiles(fileKeys);
    }

    // 3. Delete from database
    return this.submissionRepository.delete(id);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Update a submission' })
  @ApiParam({ name: 'id', description: 'Submission ID' })
  @ApiResponse({ status: 200, description: 'The submission has been successfully updated' })
  @ApiResponse({ status: 403, description: 'Forbidden' })
  @ApiResponse({ status: 404, description: 'Not Found' })
  async update(
    @Param('id') id: string,
    @Body() body: UpdateSubmissionDto,
    @Req() req: any,
  ) {
    const user = req.user as AuthenticatedUser;

    // Verify ownership
    const submission = await this.submissionRepository.findById(id);
    if (!submission) {
      throw new NotFoundException('Submission not found');
    }

    if (user.botId && submission.botId !== user.botId) {
      throw new ForbiddenException('Access denied');
    }

    // Robustly extract only valid update fields
    const updateData: any = {};
    if (body.fullName !== undefined) updateData.fullName = body.fullName;
    if (body.age !== undefined) updateData.age = body.age;
    if (body.institution !== undefined)
      updateData.institution = body.institution;
    if (body.grade !== undefined) updateData.grade = body.grade;
    if (body.city !== undefined) updateData.city = body.city;
    if (body.supervisor !== undefined) updateData.supervisor = body.supervisor;
    if (body.phone !== undefined) updateData.phone = body.phone;
    if (body.language !== undefined) updateData.language = body.language;
    if (body.category !== undefined) updateData.category = body.category;
    if (body.nomination !== undefined) updateData.nomination = body.nomination;
    if (body.projectTitle !== undefined)
      updateData.projectTitle = body.projectTitle;
    if (body.projectDesc !== undefined)
      updateData.projectDesc = body.projectDesc;
    if (body.isCertificateSent !== undefined)
      updateData.isCertificateSent = body.isCertificateSent;

    if (body.workUrl !== undefined) updateData.workUrl = body.workUrl;
    if (body.username !== undefined) updateData.username = body.username;
    if (body.comment !== undefined) updateData.comment = body.comment;

    const updated = await this.submissionRepository.update(id, updateData);
    return updated;
  }
}
