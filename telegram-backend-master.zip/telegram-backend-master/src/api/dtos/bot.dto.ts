import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsString,
  IsBoolean,
  IsOptional,
  IsObject,
  IsNotEmpty,
} from 'class-validator';
import { Type } from 'class-transformer';

export class CreateBotDto {
  @ApiProperty({ description: 'Bot name' })
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiProperty({ description: 'Telegram Bot Token' })
  @IsString()
  @IsNotEmpty()
  token: string;

  @ApiProperty({ description: 'Bot slug (unique identifier)' })
  @IsString()
  @IsNotEmpty()
  slug: string;
}

export class UpdateBotDto {
  @ApiPropertyOptional({ description: 'Bot name' })
  @IsString()
  @IsOptional()
  name?: string;

  @ApiPropertyOptional({ description: 'Telegram Bot Token' })
  @IsString()
  @IsOptional()
  token?: string;

  @ApiPropertyOptional({ description: 'Bot slug' })
  @IsString()
  @IsOptional()
  slug?: string;

  @ApiPropertyOptional({ description: 'Is bot active' })
  @IsBoolean()
  @IsOptional()
  @Type(() => Boolean)
  isActive?: boolean;

  @ApiPropertyOptional({ description: 'Bot messages configuration' })
  @IsObject()
  @IsOptional()
  messages?: any;
}
