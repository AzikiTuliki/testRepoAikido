import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsString,
  IsBoolean,
  IsOptional,
  IsEnum,
  IsNumber,
  IsNotEmpty,
} from 'class-validator';
import { Type } from 'class-transformer';
import { WorkFormat } from '@prisma/client';

export class CreateContestDto {
  @ApiProperty({ description: 'Contest name' })
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiPropertyOptional({ description: 'Description' })
  @IsString()
  @IsOptional()
  description?: string;

  @ApiPropertyOptional({ description: 'Is contest active' })
  @IsBoolean()
  @IsOptional()
  @Type(() => Boolean)
  isActive?: boolean;

  @ApiPropertyOptional({ description: 'Display order' })
  @IsNumber()
  @IsOptional()
  @Type(() => Number)
  order?: number;

  @ApiPropertyOptional({
    description: 'Work submission format',
    enum: WorkFormat,
  })
  @IsEnum(WorkFormat)
  @IsOptional()
  workFormat?: WorkFormat;

  @ApiProperty({ description: 'Bot ID' })
  @IsString()
  @IsNotEmpty()
  botId: string;
}

export class UpdateContestDto {
  @ApiPropertyOptional({ description: 'Contest name' })
  @IsString()
  @IsOptional()
  name?: string;

  @ApiPropertyOptional({ description: 'Description' })
  @IsString()
  @IsOptional()
  description?: string;

  @ApiPropertyOptional({ description: 'Is contest active' })
  @IsBoolean()
  @IsOptional()
  @Type(() => Boolean)
  isActive?: boolean;

  @ApiPropertyOptional({ description: 'Display order' })
  @IsNumber()
  @IsOptional()
  @Type(() => Number)
  order?: number;

  @ApiPropertyOptional({
    description: 'Work submission format',
    enum: WorkFormat,
  })
  @IsEnum(WorkFormat)
  @IsOptional()
  workFormat?: WorkFormat;

  @ApiPropertyOptional({ description: 'Bot ID' })
  @IsString()
  @IsOptional()
  botId?: string;
}
