import { ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsString,
  IsBoolean,
  IsOptional,
  IsNumber,
} from 'class-validator';
import { Type } from 'class-transformer';

export class UpdateSubmissionDto {
  @ApiPropertyOptional({ description: 'Full name' })
  @IsString()
  @IsOptional()
  fullName?: string;

  @ApiPropertyOptional({ description: 'Age' })
  @IsString()
  @IsOptional()
  age?: string;

  @ApiPropertyOptional({ description: 'Institution name' })
  @IsString()
  @IsOptional()
  institution?: string;

  @ApiPropertyOptional({ description: 'Grade' })
  @IsString()
  @IsOptional()
  grade?: string;

  @ApiPropertyOptional({ description: 'City' })
  @IsString()
  @IsOptional()
  city?: string;

  @ApiPropertyOptional({ description: 'Supervisor' })
  @IsString()
  @IsOptional()
  supervisor?: string;

  @ApiPropertyOptional({ description: 'Phone number' })
  @IsString()
  @IsOptional()
  phone?: string;

  @ApiPropertyOptional({ description: 'Language' })
  @IsString()
  @IsOptional()
  language?: string;

  @ApiPropertyOptional({ description: 'Category' })
  @IsString()
  @IsOptional()
  category?: string;

  @ApiPropertyOptional({ description: 'Nomination' })
  @IsString()
  @IsOptional()
  nomination?: string;

  @ApiPropertyOptional({ description: 'Project Title' })
  @IsString()
  @IsOptional()
  projectTitle?: string;

  @ApiPropertyOptional({ description: 'Project Description' })
  @IsString()
  @IsOptional()
  projectDesc?: string;

  @ApiPropertyOptional({ description: 'Is certificate sent' })
  @IsBoolean()
  @IsOptional()
  @Type(() => Boolean)
  isCertificateSent?: boolean;

  @ApiPropertyOptional({ description: 'External work URL' })
  @IsString()
  @IsOptional()
  workUrl?: string;

  @ApiPropertyOptional({ description: 'Telegram username' })
  @IsString()
  @IsOptional()
  username?: string;

  @ApiPropertyOptional({ description: 'Admin comment' })
  @IsString()
  @IsOptional()
  comment?: string;
}

export class FindAllSubmissionsDto {
  @ApiPropertyOptional({ description: 'Number of records to skip' })
  @IsNumber()
  @IsOptional()
  @Type(() => Number)
  skip?: number;

  @ApiPropertyOptional({ description: 'Number of records to take' })
  @IsNumber()
  @IsOptional()
  @Type(() => Number)
  take?: number;

  @ApiPropertyOptional({ description: 'Search query' })
  @IsString()
  @IsOptional()
  search?: string;

  @ApiPropertyOptional({ description: 'Filter by contest ID' })
  @IsString()
  @IsOptional()
  contestId?: string;

  @ApiPropertyOptional({ description: 'Filter by bot ID' })
  @IsString()
  @IsOptional()
  botId?: string;

  @ApiPropertyOptional({ description: 'Filter by language' })
  @IsString()
  @IsOptional()
  language?: string;
}
