import { Module } from '@nestjs/common';
import { TelegrafModule } from 'nestjs-telegraf';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { BotUpdate } from './bot.update';
import { StateService } from './services/state.service';
import { ValidationService } from './services/validation.service';
import { I18nService } from './services/i18n.service';
import { BotService } from './services/bot.service';
import { DatabaseModule } from '../database/database.module';
import { BotRegistryService } from './services/bot-registry.service';

@Module({
  imports: [
    DatabaseModule,
    TelegrafModule.forRootAsync({
      imports: [ConfigModule],
      useFactory: (configService: ConfigService) => ({
        token: configService.get<string>('telegram.botToken')!,
        launchOptions: {
          dropPendingUpdates: true,
        },
      }),
      inject: [ConfigService],
    }),
    TelegrafModule.forRootAsync({
      botName: 'MADENIET_BOT',
      imports: [ConfigModule],
      useFactory: (configService: ConfigService) => {
        const token = configService.get<string>('telegram.madenietBotToken');
        if (!token) {
          // Fallback to a placeholder or skip if not provided
          // But it's better to provide a token to avoid start failure
          return {
            token: 'dummy_token_to_avoid_failure',
            launchOptions: { dropPendingUpdates: true },
          };
        }
        return {
          token,
          launchOptions: {
            dropPendingUpdates: true,
          },
        };
      },
      inject: [ConfigService],
    }),
  ],
  providers: [
    BotUpdate,
    StateService,
    ValidationService,
    I18nService,
    BotService,
    BotRegistryService,
  ],
  exports: [BotService, BotRegistryService, I18nService],
})
export class BotModule {}
