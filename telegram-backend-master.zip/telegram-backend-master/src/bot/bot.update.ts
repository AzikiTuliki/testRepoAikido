import {
  Update,
  Ctx,
  Start,
  Command,
  On,
  Action,
  InjectBot,
} from 'nestjs-telegraf';
import { Context, Telegraf, Markup } from 'telegraf';
import { Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { StateService, UserState } from './services/state.service';
import { ValidationService } from './services/validation.service';
import { I18nService } from './services/i18n.service';
import { MinioService } from '../storage/minio.service';
import { SubmissionRepository } from '../database/repositories/submission.repository';
import { ContestRepository } from '../database/repositories/contest.repository';
import { BotState } from './constants/states.enum';
import { Language } from './constants/messages';
import { Readable } from 'stream';
import { WorkFormat } from '@prisma/client';
import * as https from 'https';
import * as http from 'http';
import { BotRegistryService } from './services/bot-registry.service';
import sharp from 'sharp';

@Update()
export class BotUpdate {
  private readonly logger = new Logger(BotUpdate.name);

  constructor(
    @InjectBot() private readonly bot: Telegraf<Context>,
    private readonly stateService: StateService,
    private readonly validationService: ValidationService,
    private readonly i18nService: I18nService,
    private readonly minioService: MinioService,
    private readonly submissionRepository: SubmissionRepository,
    private readonly contestRepository: ContestRepository,
    private readonly configService: ConfigService,
    private readonly botRegistry: BotRegistryService,
  ) {}

  private getBotId(ctx: Context): string {
    const token = (ctx.telegram as any).token as string;
    const botId = this.botRegistry.getBotId(token);
    if (!botId) {
      throw new Error('Bot not found in registry');
    }
    return botId;
  }

  private getBotSlug(ctx: Context): string | undefined {
    const token = (ctx.telegram as any).token as string;
    const bot = this.botRegistry.getBot(token);
    return bot?.slug;
  }

  // ==================== COMMANDS ====================

  @Start()
  async onStart(@Ctx() ctx: Context) {
    if (!ctx.from) return;
    const userId = ctx.from.id;
    const username = ctx.from.username;
    const botId = this.getBotId(ctx);

    // Get current language or default to Kazakh
    const currentState = this.stateService.getState(userId, botId);
    const lang = currentState?.language || 'kz';

    if (
      currentState &&
      currentState.step !== BotState.IDLE &&
      currentState.step !== BotState.SELECT_CONTEST
    ) {
      // Ask if they want to continue or restart
      await ctx.reply(
        this.i18nService.t(
          'status_active',
          lang,
          {
            ...currentState.draftData,
            step: this.getStepName(ctx, currentState.step, lang),
          },
          this.getBotSlug(ctx),
        ),
        Markup.inlineKeyboard([
          [
            Markup.button.callback(
              '➡️ Жалғастыру / Продолжить',
              'resume_submission',
            ),
          ],
          [
            Markup.button.callback(
              '🔄 Қайта бастау / Начать заново',
              'restart_submission',
            ),
          ],
        ]),
      );
      return;
    }

    // Initialize new session with SELECT_CONTEST step
    this.stateService.initializeState(userId, botId, username, lang);

    await this.showContestSelection(ctx, lang);
  }

  @Action('resume_submission')
  async onResume(@Ctx() ctx: Context) {
    if (!ctx.from) return;
    const userId = ctx.from.id;
    const botId = this.getBotId(ctx);
    const state = this.stateService.getState(userId, botId);
    if (!state) return;
    await ctx.answerCbQuery();
    await this.promptForStep(ctx, state.step, state.language);
  }

  @Action('restart_submission')
  async onRestart(@Ctx() ctx: Context) {
    if (!ctx.from) return;
    const userId = ctx.from.id;
    const botId = this.getBotId(ctx);
    const username = ctx.from.username;
    const state = this.stateService.getState(userId, botId);
    const lang = state?.language || 'kz';
    this.stateService.initializeState(userId, botId, username, lang);
    await ctx.answerCbQuery();
    await this.showContestSelection(ctx, lang);
  }

  private async showContestSelection(ctx: Context, lang: Language) {
    const botId = this.getBotId(ctx);
    const contests = await this.contestRepository.findAllActive(botId);

    const buttons = contests.map((c) => [
      Markup.button.callback(c.name || 'Қатысу', `select_contest_${c.id}`),
    ]);

    const keyboard = Markup.inlineKeyboard(buttons);

    const message = [
      this.i18nService.t('start_header', lang, undefined, this.getBotSlug(ctx)),
      '',
      '⸻',
      '',
      'Таңдаған байқауыңыз бойынша:',
      '📝 Қатысушы мәліметін толтырасыз',
      '📎 Жобаның видеосын жіберісіз',
      '💳 Төлем жасап, түбіртек тіркейсіз',
      '',
      this.i18nService.t(
        'confirmation_received',
        lang,
        undefined,
        this.getBotSlug(ctx),
      ),
      '',
      this.i18nService.t(
        'multiple_participation',
        lang,
        undefined,
        this.getBotSlug(ctx),
      ),
    ].join('\n');

    await ctx.reply(message, keyboard);
  }

  @Action(/^select_contest_(.+)$/)
  async onSelectContest(@Ctx() ctx: Context) {
    if (!ctx.from || !ctx.callbackQuery || !('data' in ctx.callbackQuery))
      return;
    const userId = ctx.from.id;
    const botId = this.getBotId(ctx);
    const contestId = (ctx.callbackQuery as any).data.replace(
      'select_contest_',
      '',
    );

    const contest = await this.contestRepository.findById(contestId);
    if (!contest || contest.botId !== botId) {
      await ctx.answerCbQuery('❌ Contest not found');
      return;
    }

    const state = this.stateService.getState(userId, botId);
    const lang = state?.language || 'kz';

    this.stateService.updateState(userId, botId, { contestId });

    const keyboard = Markup.inlineKeyboard([
      [
        Markup.button.callback(
          this.i18nService.t(
            'start_submission_button',
            lang,
            undefined,
            this.getBotSlug(ctx),
          ),
          `start_contest_submission_${contestId}`,
        ),
      ],
      [
        Markup.button.callback(
          this.i18nService.t(
            'back_to_contests_button',
            lang,
            undefined,
            this.getBotSlug(ctx),
          ),
          'back_to_contests',
        ),
      ],
    ]);

    await ctx.answerCbQuery();
    await ctx.reply(contest.description || contest.name || 'Қатысу', keyboard);
  }

  @Action('back_to_contests')
  async onBackToContests(@Ctx() ctx: Context) {
    if (!ctx.from) return;
    const userId = ctx.from.id;
    const botId = this.getBotId(ctx);
    const state = this.stateService.getState(userId, botId);
    const lang = state?.language || 'kz';

    await ctx.answerCbQuery();
    await this.showContestSelection(ctx, lang);
  }

  @Action(/^start_contest_submission_(.+)$/)
  async onStartContestSubmission(@Ctx() ctx: Context) {
    if (!ctx.from || !ctx.callbackQuery || !('data' in ctx.callbackQuery))
      return;
    const userId = ctx.from.id;
    const botId = this.getBotId(ctx);
    const state = this.stateService.getState(userId, botId);
    const lang = state?.language || 'kz';

    this.stateService.updateState(userId, botId, {
      step: BotState.STEP_FULL_NAME,
    });

    await ctx.answerCbQuery();
    await ctx.reply(
      this.i18nService.t(
        'step_full_name',
        lang,
        undefined,
        this.getBotSlug(ctx),
        true,
      ),
    );
  }

  @Command('cancel')
  async onCancel(@Ctx() ctx: Context) {
    if (!ctx.from) return;
    const userId = ctx.from.id;
    const botId = this.getBotId(ctx);
    const state = this.stateService.getState(userId, botId);
    const lang = state?.language || 'kz';

    this.stateService.clearState(userId, botId);
    await ctx.reply(
      this.i18nService.t('cancel', lang, undefined, this.getBotSlug(ctx)),
    );
  }

  @Action('back_step')
  async onBackStep(@Ctx() ctx: Context) {
    if (!ctx.from) return;
    const userId = ctx.from.id;
    const botId = this.getBotId(ctx);
    const state = this.stateService.getState(userId, botId);
    if (!state) return;

    const prevStep = this.getPreviousStep(ctx, state.step);
    if (!prevStep) {
      await ctx.answerCbQuery();
      await this.showContestSelection(ctx, state.language);
      return;
    }

    this.stateService.updateState(userId, botId, { step: prevStep });
    await ctx.answerCbQuery();
    await this.promptForStep(ctx, prevStep, state.language);
  }

  private getPreviousStep(ctx: Context, step: BotState): BotState | null {
    const slug = this.getBotSlug(ctx);
    const isMadeniet = slug?.includes('madeniet');

    const steps = [
      BotState.SELECT_CONTEST,
      BotState.STEP_FULL_NAME,
      BotState.STEP_AGE,
      BotState.STEP_GRADE,
      BotState.STEP_CITY,
      BotState.STEP_INSTITUTION,
      BotState.STEP_SUPERVISOR,
      BotState.STEP_PHONE,
      BotState.STEP_CATEGORY,
      BotState.STEP_NOMINATION,
      ...(isMadeniet
        ? [BotState.STEP_WORK]
        : [
            BotState.STEP_PROJECT_TITLE,
            BotState.STEP_PROJECT_DESC,
            BotState.STEP_VIDEO,
          ]),
      BotState.STEP_PAYMENT,
      BotState.STEP_CONFIRM,
    ];
    const idx = steps.indexOf(step);
    return idx > 0 ? steps[idx - 1] : null;
  }

  private async promptForStep(ctx: Context, step: BotState, lang: Language) {
    const botSlug = this.getBotSlug(ctx);
    const backButton = Markup.inlineKeyboard([
      [
        Markup.button.callback(
          this.i18nService.t('back_button', lang, undefined, botSlug),
          'back_step',
        ),
      ],
    ]);

    switch (step) {
      case BotState.SELECT_CONTEST:
        await this.showContestSelection(ctx, lang);
        break;
      case BotState.STEP_FULL_NAME:
        await ctx.reply(
          this.i18nService.t('step_full_name', lang, undefined, botSlug, true),
          backButton,
        );
        break;
      case BotState.STEP_AGE:
        await ctx.reply(
          this.i18nService.t('step_age', lang, undefined, botSlug, true),
          backButton,
        );
        break;
      case BotState.STEP_GRADE:
        await ctx.reply(
          this.i18nService.t('step_grade', lang, undefined, botSlug, true),
          backButton,
        );
        break;
      case BotState.STEP_INSTITUTION:
        await ctx.reply(
          this.i18nService.t(
            'step_institution',
            lang,
            undefined,
            botSlug,
            true,
          ),
          backButton,
        );
        break;
      case BotState.STEP_CITY:
        await ctx.reply(
          this.i18nService.t('step_city', lang, undefined, botSlug, true),
          backButton,
        );
        break;
      case BotState.STEP_SUPERVISOR:
        await ctx.reply(
          this.i18nService.t('step_supervisor', lang, undefined, botSlug, true),
          backButton,
        );
        break;
      case BotState.STEP_PHONE:
        await ctx.reply(
          this.i18nService.t('step_phone', lang, undefined, botSlug, true),
          backButton,
        );
        break;
      case BotState.STEP_CATEGORY:
        await ctx.reply(
          this.i18nService.t('step_category', lang, undefined, botSlug, true),
          this.buildCategoryKeyboard(ctx, lang),
        );
        break;
      case BotState.STEP_NOMINATION:
        await ctx.reply(
          this.i18nService.t('step_nomination', lang, undefined, botSlug, true),
          this.buildNominationKeyboard(ctx, lang),
        );
        break;
      case BotState.STEP_PROJECT_TITLE:
        await ctx.reply(
          this.i18nService.t(
            'step_project_title',
            lang,
            undefined,
            botSlug,
            true,
          ),
          backButton,
        );
        break;
      case BotState.STEP_PROJECT_DESC:
        await ctx.reply(
          this.i18nService.t(
            'step_project_desc',
            lang,
            undefined,
            botSlug,
            true,
          ),
          backButton,
        );
        break;
      case BotState.STEP_VIDEO:
        await ctx.reply(
          this.i18nService.t('step_video', lang, undefined, botSlug, true),
          backButton,
        );
        break;
      case BotState.STEP_WORK:
        await ctx.reply(
          this.i18nService.t('step_work_photo', lang, undefined, botSlug, true),
          backButton,
        );
        break;
      case BotState.STEP_PAYMENT:
        await ctx.reply(
          this.i18nService.t('step_payment', lang, undefined, botSlug, true),
          backButton,
        );
        break;
      case BotState.STEP_CONFIRM:
        const userId = ctx.from!.id;
        const botId = this.getBotId(ctx);
        await this.showConfirmation(ctx, userId, botId, lang);
        break;
      default:
        break;
    }
  }

  @Command('status')
  async onStatus(@Ctx() ctx: Context) {
    if (!ctx.from) return;
    const userId = ctx.from.id;
    const botId = this.getBotId(ctx);
    const state = this.stateService.getState(userId, botId);
    const lang = state?.language || 'kz';

    if (!state || state.step === BotState.IDLE) {
      // If no active session, try to show the last submission status
      const lastSubmissions =
        await this.submissionRepository.findByTelegramUserId(BigInt(userId));

      // Filter by current botId
      const botSubmissions = lastSubmissions.filter(
        (s) => s.botId === botId || !s.botId,
      );

      if (botSubmissions.length > 0) {
        const last = botSubmissions[0];
        const notSet = this.i18nService.t(
          'placeholder_not_set',
          lang,
          undefined,
          this.getBotSlug(ctx),
        );

        const message = this.i18nService.t(
          'last_submission_info',
          lang,
          {
            regNumber: last.regNumber.toString(),
            fullName: last.fullName || notSet,
            category: last.category || notSet,
            nomination: last.nomination || notSet,
            projectDesc: last.projectDesc || notSet,
            comment: (last as any).comment || notSet,
          },
          this.getBotSlug(ctx),
        );
        await ctx.reply(message);
        return;
      }

      await ctx.reply(
        this.i18nService.t(
          'status_idle',
          lang,
          undefined,
          this.getBotSlug(ctx),
        ),
      );
      return;
    }

    const stepName = this.getStepName(ctx, state.step, lang);
    const notSet = this.i18nService.t(
      'placeholder_not_set',
      lang,
      undefined,
      this.getBotSlug(ctx),
    );

    const message = this.i18nService.t('status_active', lang, {
      fullName: state.draftData.fullName || notSet,
      age: state.draftData.age || notSet,
      grade: state.draftData.grade || notSet,
      institution: state.draftData.institution || notSet,
      city: state.draftData.city || notSet,
      supervisor: state.draftData.supervisor || notSet,
      phone: state.draftData.phone || notSet,
      category: state.draftData.category || notSet,
      nomination: state.draftData.nomination || notSet,
      projectTitle: state.draftData.projectTitle || notSet,
      videoUrl: state.draftData.videoUrl || notSet,
      payment: state.paymentFile?.fileName || notSet,
      step: stepName,
    });

    await ctx.reply(message);
  }

  @Command('help')
  async onHelp(@Ctx() ctx: Context) {
    if (!ctx.from) return;
    const userId = ctx.from.id;
    const botId = this.getBotId(ctx);
    const state = this.stateService.getState(userId, botId);
    const lang = state?.language || 'kz';

    await ctx.reply(
      this.i18nService.t('help', lang, undefined, this.getBotSlug(ctx)),
    );
  }

  // ==================== MESSAGE HANDLERS ====================

  @On('text')
  async onText(@Ctx() ctx: Context) {
    if (!ctx.from) return;

    if (
      ctx.message &&
      'text' in ctx.message &&
      ctx.message.text.startsWith('/')
    ) {
      return;
    }

    const userId = ctx.from.id;
    const botId = this.getBotId(ctx);
    const state = this.stateService.getState(userId, botId);
    if (!state) return;

    const lang = state.language;
    const text = ctx.message && 'text' in ctx.message ? ctx.message.text : '';

    switch (state.step) {
      case BotState.IDLE:
        await ctx.reply(
          this.i18nService.t(
            'status_idle',
            lang,
            undefined,
            this.getBotSlug(ctx),
          ),
        );
        break;

      case BotState.SELECT_CONTEST:
        await ctx.reply(
          this.i18nService.t(
            'error_select_contest_first',
            lang,
            undefined,
            this.getBotSlug(ctx),
          ),
        );
        await this.showContestSelection(ctx, lang);
        break;

      // ── Section 1: Participant Info ──────────────────────────
      case BotState.STEP_FULL_NAME:
        await this.handleSimpleInput(
          ctx,
          userId,
          botId,
          'fullName',
          text,
          BotState.STEP_AGE,
          state,
        );
        break;

      case BotState.STEP_AGE:
        await this.handleAgeInput(ctx, userId, botId, text, state);
        break;

      case BotState.STEP_GRADE:
        await this.handleSimpleInput(
          ctx,
          userId,
          botId,
          'grade',
          text,
          BotState.STEP_CITY,
          state,
        );
        break;

      case BotState.STEP_CITY:
        await this.handleSimpleInput(
          ctx,
          userId,
          botId,
          'city',
          text,
          BotState.STEP_INSTITUTION,
          state,
        );
        break;

      case BotState.STEP_INSTITUTION:
        await this.handleSimpleInput(
          ctx,
          userId,
          botId,
          'institution',
          text,
          BotState.STEP_SUPERVISOR,
          state,
        );
        break;

      case BotState.STEP_SUPERVISOR:
        await this.handleSimpleInput(
          ctx,
          userId,
          botId,
          'supervisor',
          text,
          BotState.STEP_PHONE,
          state,
        );
        break;

      case BotState.STEP_PHONE:
        {
          await this.handlePhoneInput(
            ctx,
            userId,
            botId,
            text,
            state,
            BotState.STEP_CATEGORY,
          );
        }
        break;

      // ── Section 2: Contest Info ──────────────────────────────
      case BotState.STEP_CATEGORY:
        await ctx.reply(
          this.i18nService.t(
            'error_use_buttons',
            lang,
            undefined,
            this.getBotSlug(ctx),
          ),
          this.buildCategoryKeyboard(ctx, lang),
        );
        break;

      case BotState.STEP_NOMINATION:
        await ctx.reply(
          this.i18nService.t(
            'error_use_buttons',
            lang,
            undefined,
            this.getBotSlug(ctx),
          ),
          this.buildNominationKeyboard(ctx, lang),
        );
        break;

      case BotState.STEP_PROJECT_TITLE:
        await this.handleSimpleInput(
          ctx,
          userId,
          botId,
          'projectTitle',
          text,
          BotState.STEP_PROJECT_DESC,
          state,
        );
        break;

      case BotState.STEP_PROJECT_DESC:
        await this.handleProjectDesc(ctx, userId, botId, text, state);
        break;

      // ── Section 3: Work ─────────────────────────────────────
      case BotState.STEP_VIDEO:
        await this.handleVideoLink(ctx, userId, botId, text, state);
        break;

      case BotState.STEP_WORK:
        await this.handleWorkLink(ctx, userId, botId, text, state);
        break;

      // ── Section 4: Payment ───────────────────────────────────
      case BotState.STEP_PAYMENT:
      case BotState.STEP_PAYMENT_CONFIRM:
        if (ctx.message && 'document' in ctx.message) break; // Handled by onDocument
        await ctx.reply(
          this.i18nService.t(
            'error_pdf_only',
            lang,
            undefined,
            this.getBotSlug(ctx),
          ),
        );
        break;

      default:
        break;
    }
  }

  @On('document')
  async onDocument(@Ctx() ctx: Context) {
    if (!ctx.from) return;
    const userId = ctx.from.id;
    const botId = this.getBotId(ctx);
    const state = this.stateService.getState(userId, botId);
    if (!state) return;

    const document =
      ctx.message && 'document' in ctx.message ? ctx.message.document : null;
    if (!document) return;

    try {
      if (
        state.step === BotState.STEP_PAYMENT ||
        state.step === BotState.STEP_PAYMENT_CONFIRM
      ) {
        await this.handlePaymentUpload(ctx, userId, botId, document, state);
      } else if (state.step === BotState.STEP_WORK) {
        await this.handleWorkUpload(ctx, userId, botId, document, state);
      } else if (state.step === BotState.STEP_VIDEO) {
        await ctx.reply(
          this.i18nService.t(
            'error_no_video',
            state.language,
            undefined,
            this.getBotSlug(ctx),
          ),
        );
      }
    } catch (error) {
      this.logger.error(`Document processing failed: ${error.message}`);
      await ctx.reply(
        this.i18nService.t(
          'support_contact',
          state.language,
          undefined,
          this.getBotSlug(ctx),
        ),
      );
    }
  }

  @On('photo')
  async onPhoto(@Ctx() ctx: Context) {
    if (!ctx.from) return;
    const userId = ctx.from.id;
    const botId = this.getBotId(ctx);
    const state = this.stateService.getState(userId, botId);
    if (!state) return;
    const photo =
      ctx.message && 'photo' in ctx.message ? ctx.message.photo.pop() : null;
    if (!photo) return;

    try {
      if (state.step === BotState.STEP_WORK) {
        await this.handleWorkUpload(ctx, userId, botId, photo, state);
      } else if (state.step === BotState.STEP_VIDEO) {
        await ctx.reply(
          this.i18nService.t(
            'error_no_video',
            state.language,
            undefined,
            this.getBotSlug(ctx),
          ),
        );
      } else if (
        state.step === BotState.STEP_PAYMENT ||
        state.step === BotState.STEP_PAYMENT_CONFIRM
      ) {
        await ctx.reply(
          this.i18nService.t(
            'error_pdf_only',
            state.language,
            undefined,
            this.getBotSlug(ctx),
          ),
        );
      }
    } catch (error) {
      this.logger.error(`Photo processing failed: ${error.message}`);
      await ctx.reply(
        this.i18nService.t(
          'support_contact',
          state.language,
          undefined,
          this.getBotSlug(ctx),
        ),
      );
    }
  }

  @On(['video', 'video_note', 'animation', 'voice', 'audio'])
  async onMediaBlocked(@Ctx() ctx: Context) {
    if (!ctx.from) return;
    const userId = ctx.from.id;
    const botId = this.getBotId(ctx);
    const state = this.stateService.getState(userId, botId);
    if (!state) return;

    if (
      state.step === BotState.STEP_VIDEO ||
      state.step === BotState.STEP_WORK ||
      state.step === BotState.STEP_PAYMENT ||
      state.step === BotState.STEP_PAYMENT_CONFIRM
    ) {
      await ctx.reply(
        this.i18nService.t(
          'error_no_video',
          state.language,
          undefined,
          this.getBotSlug(ctx),
        ),
      );
    }
  }

  // ==================== INLINE BUTTON CALLBACKS ====================

  /** Category selection buttons */
  @Action(/^robo_category_(.+)$/)
  async onCategorySelect(@Ctx() ctx: Context) {
    if (!ctx.from || !ctx.callbackQuery || !('data' in ctx.callbackQuery))
      return;
    const userId = ctx.from.id;
    const botId = this.getBotId(ctx);
    const state = this.stateService.getState(userId, botId);
    if (!state) return;

    const lang = state.language;
    const slug = this.getBotSlug(ctx);
    const rawCategory = (ctx.callbackQuery as any).data.replace(
      'robo_category_',
      '',
    );

    // Map key → human-readable label
    const categoryLabels: Record<string, string> = {
      junior: this.i18nService.t('category_junior', lang, undefined, slug),
      beginner: this.i18nService.t('category_beginner', lang, undefined, slug),
      intermediate: this.i18nService.t(
        'category_intermediate',
        lang,
        undefined,
        slug,
      ),
      advanced: this.i18nService.t('category_advanced', lang, undefined, slug),
      // Madeniet specific
      shuaqty: this.i18nService.t(
        'madeniet_category_shuaqty',
        lang,
        undefined,
        slug,
      ),
      nauryz: this.i18nService.t(
        'madeniet_category_nauryz',
        lang,
        undefined,
        slug,
      ),
    };

    const category = categoryLabels[rawCategory] || rawCategory;

    this.stateService.updateState(userId, botId, {
      draftData: { ...state.draftData, category },
      step: BotState.STEP_NOMINATION,
    });

    await ctx.answerCbQuery();
    await this.promptForStep(ctx, BotState.STEP_NOMINATION, lang);
  }

  /** Nomination selection buttons */
  @Action(/^robo_nomination_(.+)$/)
  async onNominationSelect(@Ctx() ctx: Context) {
    if (!ctx.from || !ctx.callbackQuery || !('data' in ctx.callbackQuery))
      return;
    const userId = ctx.from.id;
    const botId = this.getBotId(ctx);
    const state = this.stateService.getState(userId, botId);
    if (!state) return;

    const lang = state.language;
    const slug = this.getBotSlug(ctx);
    const rawNomination = (ctx.callbackQuery as any).data.replace(
      'robo_nomination_',
      '',
    );

    const nominationLabels: Record<string, string> = {
      obstacle: this.i18nService.t(
        'nomination_obstacle',
        lang,
        undefined,
        slug,
      ),
      smart: this.i18nService.t('nomination_smart', lang, undefined, slug),
      startup: this.i18nService.t('nomination_startup', lang, undefined, slug),
      // Madeniet specific
      '1190': this.i18nService.t(
        'madeniet_nomination_1190',
        lang,
        undefined,
        slug,
      ),
      '5990': this.i18nService.t(
        'madeniet_nomination_5990',
        lang,
        undefined,
        slug,
      ),
      '9990': this.i18nService.t(
        'madeniet_nomination_9990',
        lang,
        undefined,
        slug,
      ),
    };

    const nomination = nominationLabels[rawNomination] || rawNomination;
    const isMadeniet = slug?.includes('madeniet');
    const nextStep = isMadeniet
      ? BotState.STEP_WORK
      : BotState.STEP_PROJECT_TITLE;

    this.stateService.updateState(userId, botId, {
      draftData: { ...state.draftData, nomination },
      step: nextStep,
    });

    await ctx.answerCbQuery();
    await this.promptForStep(ctx, nextStep, lang);
  }

  /** Confirmation: YES – all data is correct, proceed to submit */
  @Action('confirm_yes')
  async onConfirmYes(@Ctx() ctx: Context) {
    if (!ctx.from) return;
    const userId = ctx.from.id;
    const botId = this.getBotId(ctx);
    const state = this.stateService.getState(userId, botId);
    if (!state) return;

    const lang = state.language;

    try {
      const submission = await this.submissionRepository.create({
        telegramUserId: BigInt(userId),
        username: state.username,
        language: lang,
        contestId: state.contestId!,
        botId: state.botId,
        // Section 1
        fullName: state.draftData.fullName!,
        age: state.draftData.age,
        institution: state.draftData.institution!,
        grade: state.draftData.grade!,
        city: state.draftData.city,
        supervisor: state.draftData.supervisor!,
        phone: state.draftData.phone!,
        // Section 2
        category: state.draftData.category,
        nomination: state.draftData.nomination,
        projectTitle: state.draftData.projectTitle,
        projectDesc: state.draftData.projectDesc,
        // Section 3
        videoUrl: state.draftData.videoUrl,
        workUrl: state.draftData.workUrl,
        workFileId: state.workFile?.fileId,
        workFileName: state.workFile?.fileName,
        // Section 4
        paymentFileId: state.paymentFile!.fileId,
        paymentFileName: state.paymentFile!.fileName,
        paymentObjectKey: state.paymentFile!.fileId,
      });

      this.stateService.clearState(userId, botId);
      await ctx.answerCbQuery();
      await ctx.reply(
        this.i18nService.t(
          'success',
          lang,
          { regNumber: submission.regNumber.toString() },
          this.getBotSlug(ctx),
        ),
      );
    } catch (error) {
      this.logger.error(`Error saving: ${error.message}`);
      await ctx.answerCbQuery();
      await ctx.reply(
        this.i18nService.t(
          'support_contact',
          lang,
          undefined,
          this.getBotSlug(ctx),
        ),
      );
    }
  }

  /** Confirmation: NO – go back to edit from the start */
  @Action('confirm_no')
  async onConfirmNo(@Ctx() ctx: Context) {
    if (!ctx.from) return;
    const userId = ctx.from.id;
    const botId = this.getBotId(ctx);
    const state = this.stateService.getState(userId, botId);
    if (!state) return;

    const lang = state.language;

    this.stateService.updateState(userId, botId, {
      step: BotState.STEP_FULL_NAME,
      editingField: undefined,
    });

    await ctx.answerCbQuery();
    await ctx.reply(
      this.i18nService.t(
        'confirm_edit_prompt',
        lang,
        undefined,
        this.getBotSlug(ctx),
      ),
    );
    await ctx.reply(
      this.i18nService.t(
        'step_full_name',
        lang,
        undefined,
        this.getBotSlug(ctx),
        true,
      ),
    );
  }

  /** Legacy confirm (kept for backward compat) */
  @Action('confirm')
  async onConfirm(@Ctx() ctx: Context) {
    return this.onConfirmYes(ctx);
  }

  @Action('edit')
  async onEdit(@Ctx() ctx: Context) {
    if (!ctx.from) return;
    const userId = ctx.from.id;
    const botId = this.getBotId(ctx);
    const state = this.stateService.getState(userId, botId);
    if (!state) return;

    this.stateService.updateState(userId, botId, {
      step: BotState.STEP_FULL_NAME,
      editingField: undefined,
    });

    await ctx.answerCbQuery();
    await ctx.reply(
      this.i18nService.t(
        'step_full_name',
        state.language,
        undefined,
        this.getBotSlug(ctx),
        true,
      ),
    );
  }

  // ==================== HELPERS ====================

  private buildCategoryKeyboard(ctx: Context, lang: Language) {
    const slug = this.getBotSlug(ctx);
    const isMadeniet = slug?.includes('madeniet');

    if (isMadeniet) {
      return Markup.inlineKeyboard([
        [
          Markup.button.callback(
            this.i18nService.t(
              'madeniet_category_shuaqty',
              lang,
              undefined,
              slug,
            ),
            'robo_category_shuaqty',
          ),
        ],
        [
          Markup.button.callback(
            this.i18nService.t(
              'madeniet_category_nauryz',
              lang,
              undefined,
              slug,
            ),
            'robo_category_nauryz',
          ),
        ],
        [
          Markup.button.callback(
            this.i18nService.t('back_button', lang, undefined, slug),
            'back_step',
          ),
        ],
      ]);
    }

    return Markup.inlineKeyboard([
      [
        Markup.button.callback(
          this.i18nService.t('category_junior', lang, undefined, slug),
          'robo_category_junior',
        ),
      ],
      [
        Markup.button.callback(
          this.i18nService.t('category_beginner', lang, undefined, slug),
          'robo_category_beginner',
        ),
      ],
      [
        Markup.button.callback(
          this.i18nService.t('category_intermediate', lang, undefined, slug),
          'robo_category_intermediate',
        ),
      ],
      [
        Markup.button.callback(
          this.i18nService.t('category_advanced', lang, undefined, slug),
          'robo_category_advanced',
        ),
      ],
      [
        Markup.button.callback(
          this.i18nService.t('back_button', lang, undefined, slug),
          'back_step',
        ),
      ],
    ]);
  }

  private buildNominationKeyboard(ctx: Context, lang: Language) {
    const slug = this.getBotSlug(ctx);
    const isMadeniet = slug?.includes('madeniet');

    if (isMadeniet) {
      return Markup.inlineKeyboard([
        [
          Markup.button.callback(
            this.i18nService.t(
              'madeniet_nomination_1190',
              lang,
              undefined,
              slug,
            ),
            'robo_nomination_1190',
          ),
        ],
        [
          Markup.button.callback(
            this.i18nService.t(
              'madeniet_nomination_5990',
              lang,
              undefined,
              slug,
            ),
            'robo_nomination_5990',
          ),
        ],
        [
          Markup.button.callback(
            this.i18nService.t(
              'madeniet_nomination_9990',
              lang,
              undefined,
              slug,
            ),
            'robo_nomination_9990',
          ),
        ],
        [
          Markup.button.callback(
            this.i18nService.t('back_button', lang, undefined, slug),
            'back_step',
          ),
        ],
      ]);
    }

    return Markup.inlineKeyboard([
      [
        Markup.button.callback(
          this.i18nService.t('nomination_obstacle', lang, undefined, slug),
          'robo_nomination_obstacle',
        ),
      ],
      [
        Markup.button.callback(
          this.i18nService.t('nomination_smart', lang, undefined, slug),
          'robo_nomination_smart',
        ),
      ],
      [
        Markup.button.callback(
          this.i18nService.t('nomination_startup', lang, undefined, slug),
          'robo_nomination_startup',
        ),
      ],
      [
        Markup.button.callback(
          this.i18nService.t('back_button', lang, undefined, slug),
          'back_step',
        ),
      ],
    ]);
  }

  private async handleSimpleInput(
    ctx: Context,
    userId: number,
    botId: string,
    field: string,
    text: string,
    nextStep: BotState,
    state: UserState,
  ) {
    const lang = state.language;
    let validation: { valid: boolean; error?: string } = { valid: true };

    if (field === 'fullName') {
      validation = this.validationService.validateName(text);
    } else if (field === 'grade') {
      validation = this.validationService.validateGrade(text);
    } else {
      validation = this.validationService.validateSimpleText(text);
    }

    if (!validation.valid) {
      await ctx.reply(
        this.i18nService.t(
          validation.error || 'error_invalid_format',
          lang,
          undefined,
          this.getBotSlug(ctx),
        ),
      );
      return;
    }

    this.stateService.updateState(userId, botId, {
      draftData: { ...state.draftData, [field]: text.trim() },
      step: nextStep,
    });

    await this.promptForStep(ctx, nextStep, lang);
  }

  private async handleAgeInput(
    ctx: Context,
    userId: number,
    botId: string,
    text: string,
    state: UserState,
  ) {
    const lang = state.language;
    const trimmed = text.trim();

    // Age must be a number between 1 and 99
    const age = parseInt(trimmed, 10);
    if (isNaN(age) || age < 1 || age > 99 || !/^\d+$/.test(trimmed)) {
      await ctx.reply(
        this.i18nService.t(
          'error_invalid_age',
          lang,
          undefined,
          this.getBotSlug(ctx),
        ),
      );
      return;
    }

    this.stateService.updateState(userId, botId, {
      draftData: { ...state.draftData, age: trimmed },
      step: BotState.STEP_GRADE,
    });

    await this.promptForStep(ctx, BotState.STEP_GRADE, lang);
  }

  private async handlePhoneInput(
    ctx: Context,
    userId: number,
    botId: string,
    text: string,
    state: UserState,
    nextStep: BotState = BotState.STEP_CATEGORY,
  ) {
    const lang = state.language;

    const validation = this.validationService.validatePhone(text);
    if (!validation.valid) {
      await ctx.reply(
        this.i18nService.t(
          validation.error || 'error_invalid_format',
          lang,
          undefined,
          this.getBotSlug(ctx),
        ),
      );
      return;
    }

    this.stateService.updateState(userId, botId, {
      draftData: { ...state.draftData, phone: text.trim() },
      step: nextStep,
    });

    await this.promptForStep(ctx, nextStep, lang);
  }

  private async handleProjectDesc(
    ctx: Context,
    userId: number,
    botId: string,
    text: string,
    state: UserState,
  ) {
    const lang = state.language;
    if (text.trim().length < 5) {
      await ctx.reply(
        this.i18nService.t(
          'error_invalid_format',
          lang,
          undefined,
          this.getBotSlug(ctx),
        ),
      );
      return;
    }

    this.stateService.updateState(userId, botId, {
      draftData: { ...state.draftData, projectDesc: text.trim() },
      step: BotState.STEP_VIDEO,
    });

    await this.promptForStep(ctx, BotState.STEP_VIDEO, lang);
  }

  private async handleVideoLink(
    ctx: Context,
    userId: number,
    botId: string,
    text: string,
    state: UserState,
  ) {
    const lang = state.language;

    const validation = this.validationService.validateUrl(text);
    if (!validation.valid) {
      await ctx.reply(
        this.i18nService.t(
          validation.error || 'error_url_format',
          lang,
          undefined,
          this.getBotSlug(ctx),
        ),
      );
      return;
    }

    this.stateService.updateState(userId, botId, {
      draftData: { ...state.draftData, videoUrl: text.trim() },
      step: BotState.STEP_PAYMENT,
    });

    await this.promptForStep(ctx, BotState.STEP_PAYMENT, lang);
  }

  private async handleWorkLink(
    ctx: Context,
    userId: number,
    botId: string,
    text: string,
    state: UserState,
  ) {
    const lang = state.language;

    const validation = this.validationService.validateUrl(text);
    if (!validation.valid) {
      await ctx.reply(
        this.i18nService.t(
          validation.error || 'error_invalid_format',
          lang,
          undefined,
          this.getBotSlug(ctx),
        ),
      );
      return;
    }

    this.stateService.updateState(userId, botId, {
      draftData: { ...state.draftData, workUrl: text.trim() },
      step: BotState.STEP_PAYMENT,
    });

    await this.promptForStep(ctx, BotState.STEP_PAYMENT, lang);
  }

  private async handleWorkUpload(
    ctx: Context,
    userId: number,
    botId: string,
    file: any,
    state: any,
  ) {
    const lang = state.language;

    const contest = await this.contestRepository.findById(state.contestId);

    if (!state.contestId || !contest) {
      await ctx.reply(
        this.i18nService.t(
          'error_select_contest_first',
          lang,
          undefined,
          this.getBotSlug(ctx),
        ),
      );
      await this.showContestSelection(ctx, lang);
      return;
    }

    if (contest.workFormat === (WorkFormat.VIDEO as any)) {
      await ctx.reply(
        this.i18nService.t(
          'error_url_required',
          lang,
          undefined,
          this.getBotSlug(ctx),
        ),
      );
      return;
    }

    const mimeType =
      file.mime_type ||
      (file.file_unique_id ? 'image/jpeg' : 'application/octet-stream');
    const sizeBytes = file.file_size || 0;

    if (mimeType.startsWith('video/')) {
      await ctx.reply(
        this.i18nService.t(
          'error_no_video',
          lang,
          undefined,
          this.getBotSlug(ctx),
        ),
      );
      return;
    }

    const maxWorkSize = 1024 * 1024;
    if (sizeBytes > maxWorkSize) {
      if (contest?.workFormat === (WorkFormat.IMAGE as any)) {
        await ctx.reply(
          this.i18nService.t(
            'error_work_size_exceeded',
            lang,
            undefined,
            this.getBotSlug(ctx),
          ),
        );
      } else {
        await ctx.reply(
          this.i18nService.t(
            'error_pdf_size_exceeded',
            lang,
            undefined,
            this.getBotSlug(ctx),
          ),
        );
      }
      return;
    }

    const validation = this.validationService.validateFile(mimeType, sizeBytes);
    if (!validation.valid && validation.error !== 'error_file_size') {
      await ctx.reply(
        this.i18nService.t(
          validation.error || 'error_file_type',
          lang,
          undefined,
          this.getBotSlug(ctx),
        ),
      );
      return;
    }

    const {
      objectKey,
      fileName,
      mimeType: finalMime,
      sizeBytes: finalSize,
    } = await this.uploadToMinio(ctx, file, userId, 'work');

    this.stateService.updateState(userId, botId, {
      workFile: {
        fileId: objectKey,
        fileName,
        mimeType: finalMime,
        sizeBytes: finalSize,
      },
      step: BotState.STEP_PAYMENT,
    });

    await ctx.reply(
      this.i18nService.t(
        'step_payment',
        lang,
        undefined,
        this.getBotSlug(ctx),
        true,
      ),
    );
  }

  private async handlePaymentUpload(
    ctx: Context,
    userId: number,
    botId: string,
    document: any,
    state: any,
  ) {
    const lang = state.language;
    if (document.mime_type !== 'application/pdf') {
      await ctx.reply(
        this.i18nService.t(
          'error_pdf_only',
          lang,
          undefined,
          this.getBotSlug(ctx),
        ),
      );
      return;
    }

    const sizeBytes = document.file_size || 0;
    const maxPaymentSize = 500 * 1024;
    if (sizeBytes > maxPaymentSize) {
      await ctx.reply(
        this.i18nService.t(
          'error_payment_size_exceeded',
          lang,
          undefined,
          this.getBotSlug(ctx),
        ),
      );
      return;
    }

    const {
      objectKey,
      fileName,
      mimeType,
      sizeBytes: finalSize,
    } = await this.uploadToMinio(ctx, document, userId, 'payment');

    this.stateService.updateState(userId, botId, {
      paymentFile: {
        fileId: objectKey,
        fileName,
        mimeType,
        sizeBytes: finalSize,
      },
      step: BotState.STEP_CONFIRM,
    });

    await this.showConfirmation(ctx, userId, botId, lang);
  }

  private async uploadToMinio(
    ctx: Context,
    file: {
      file_id: string;
      file_unique_id?: string;
      file_name?: string;
      mime_type?: string;
    },
    userId: number,
    folder: string,
  ) {
    const fileId = file.file_id;
    const fileUniqueId = file.file_unique_id || Date.now().toString();
    const originalFileName =
      file.file_name || (folder === 'work' ? 'work.jpg' : 'check.pdf');
    let mimeType =
      file.mime_type || (folder === 'work' ? 'image/jpeg' : 'application/pdf');

    const fileLink = await ctx.telegram.getFileLink(fileId);
    let buffer = await this.downloadFileToBuffer(fileLink.href);

    if (mimeType.startsWith('image/')) {
      try {
        buffer = await sharp(buffer)
          .jpeg({ quality: 80, progressive: true, mozjpeg: true })
          .toBuffer();
        mimeType = 'image/jpeg';
      } catch (error) {
        this.logger.warn(
          `Image optimization failed, uploading original: ${error.message}`,
        );
      }
    }

    const now = new Date();
    const datePath = `${now.getFullYear()}/${(now.getMonth() + 1)
      .toString()
      .padStart(2, '0')}/${now.getDate().toString().padStart(2, '0')}`;

    const cleanFileName = originalFileName.replace(/[^a-zA-Z0-9.-]/g, '_');
    const objectKey = `submissions/${folder}/${datePath}/${userId}_${fileUniqueId}_${cleanFileName}`;

    const readable = new Readable();
    readable.push(buffer);
    readable.push(null);

    await this.minioService.uploadFile(
      objectKey,
      readable,
      mimeType,
      buffer.length,
    );
    return {
      objectKey,
      fileName: originalFileName,
      mimeType,
      sizeBytes: buffer.length,
    };
  }

  private async showConfirmation(
    ctx: Context,
    userId: number,
    botId: string,
    lang: Language,
  ) {
    const state = this.stateService.getState(userId, botId);
    if (!state) return;

    const notSet = this.i18nService.t(
      'placeholder_not_set',
      lang,
      undefined,
      this.getBotSlug(ctx),
    );

    const summary = this.i18nService.t('confirm_check_name', lang, {
      fullName: state.draftData.fullName || notSet,
      age: state.draftData.age || notSet,
      grade: state.draftData.grade || notSet,
      institution: state.draftData.institution || notSet,
      city: state.draftData.city || notSet,
      supervisor: state.draftData.supervisor || notSet,
      phone: state.draftData.phone || notSet,
      category: state.draftData.category || notSet,
      nomination: state.draftData.nomination || notSet,
      projectTitle: state.draftData.projectTitle || notSet,
      projectDesc: state.draftData.projectDesc || notSet,
      videoUrl:
        state.draftData.videoUrl ||
        state.draftData.workUrl ||
        state.workFile?.fileName ||
        notSet,
      payment: state.paymentFile?.fileName || notSet,
    });

    const keyboard = Markup.inlineKeyboard([
      [
        Markup.button.callback(
          this.i18nService.t(
            'confirm_yes_button',
            lang,
            undefined,
            this.getBotSlug(ctx),
          ),
          'confirm_yes',
        ),
      ],
      [
        Markup.button.callback(
          this.i18nService.t(
            'confirm_no_button',
            lang,
            undefined,
            this.getBotSlug(ctx),
          ),
          'confirm_no',
        ),
      ],
    ]);

    await ctx.reply(summary, keyboard);
  }

  private async downloadFileAsStream(url: string): Promise<Readable> {
    return new Promise((resolve, reject) => {
      const protocol = url.startsWith('https') ? https : http;
      protocol
        .get(url, (res) => {
          if (res.statusCode !== 200) reject(new Error('Failed download'));
          else resolve(res);
        })
        .on('error', reject);
    });
  }

  private async downloadFileToBuffer(url: string): Promise<Buffer> {
    const stream = await this.downloadFileAsStream(url);
    const chunks: Buffer[] = [];
    for await (const chunk of stream) {
      chunks.push(Buffer.from(chunk));
    }
    return Buffer.concat(chunks);
  }

  private getStepName(ctx: Context, step: BotState, lang: Language): string {
    const stepMap: Record<BotState, string> = {
      [BotState.IDLE]: '',
      [BotState.SELECT_CONTEST]: this.i18nService.t(
        'placeholder_step_select_contest',
        lang,
        undefined,
        this.getBotSlug(ctx),
      ),
      [BotState.STEP_FULL_NAME]: this.i18nService.t(
        'placeholder_step_full_name',
        lang,
        undefined,
        this.getBotSlug(ctx),
      ),
      [BotState.STEP_AGE]: this.i18nService.t(
        'placeholder_step_age',
        lang,
        undefined,
        this.getBotSlug(ctx),
      ),
      [BotState.STEP_GRADE]: this.i18nService.t(
        'placeholder_step_grade',
        lang,
        undefined,
        this.getBotSlug(ctx),
      ),
      [BotState.STEP_INSTITUTION]: this.i18nService.t(
        'placeholder_step_institution',
        lang,
        undefined,
        this.getBotSlug(ctx),
      ),
      [BotState.STEP_CITY]: this.i18nService.t(
        'placeholder_step_city',
        lang,
        undefined,
        this.getBotSlug(ctx),
      ),
      [BotState.STEP_SUPERVISOR]: this.i18nService.t(
        'placeholder_step_supervisor',
        lang,
        undefined,
        this.getBotSlug(ctx),
      ),
      [BotState.STEP_PHONE]: this.i18nService.t(
        'placeholder_step_phone',
        lang,
        undefined,
        this.getBotSlug(ctx),
      ),
      [BotState.STEP_CATEGORY]: this.i18nService.t(
        'placeholder_step_category',
        lang,
        undefined,
        this.getBotSlug(ctx),
      ),
      [BotState.STEP_NOMINATION]: this.i18nService.t(
        'placeholder_step_nomination',
        lang,
        undefined,
        this.getBotSlug(ctx),
      ),
      [BotState.STEP_PROJECT_TITLE]: this.i18nService.t(
        'placeholder_step_project_title',
        lang,
        undefined,
        this.getBotSlug(ctx),
      ),
      [BotState.STEP_PROJECT_DESC]: this.i18nService.t(
        'placeholder_step_project_desc',
        lang,
        undefined,
        this.getBotSlug(ctx),
      ),
      [BotState.STEP_VIDEO]: this.i18nService.t(
        'placeholder_step_video',
        lang,
        undefined,
        this.getBotSlug(ctx),
      ),
      [BotState.STEP_WORK]: this.i18nService.t(
        'placeholder_step_work',
        lang,
        undefined,
        this.getBotSlug(ctx),
      ),
      [BotState.STEP_PAYMENT]: this.i18nService.t(
        'placeholder_step_payment',
        lang,
        undefined,
        this.getBotSlug(ctx),
      ),
      [BotState.STEP_PAYMENT_CONFIRM]: this.i18nService.t(
        'placeholder_step_payment_confirm',
        lang,
        undefined,
        this.getBotSlug(ctx),
      ),
      [BotState.STEP_CONFIRM]: this.i18nService.t(
        'placeholder_step_confirm',
        lang,
        undefined,
        this.getBotSlug(ctx),
      ),
      [BotState.DONE]: '',
    };
    return stepMap[step] || '';
  }
}
