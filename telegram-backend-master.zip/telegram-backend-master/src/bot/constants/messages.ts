export type Language = 'kz';

export interface MessageSchema {
  [key: string]: string;
}

const ROBOSTART_MESSAGES: Record<Language, MessageSchema> = {
  kz: {
    // Commands
    start_header:
      'Сәлеметсіз бе! 👋\nRoboStart – Республикалық робототехника олимпиадасына қош келдіңіз!\n\nӨтініш беру үшін төмендегі сұрақтарға жауап беріңіз.',
    cancel:
      '❌ Операция тоқтатылды. Барлық деректер жойылды.\n\nҚайта бастау үшін /start пайдаланыңыз.',
    status_idle:
      '📊 Статус: Белсенді сессия жоқ.\n\nБастау үшін /start пайдаланыңыз.',
    last_submission_info:
      '📊 Соңғы өтінішіңіздің статусы (№{regNumber}):\n\n👤 ТАӘ: {fullName}\n🏆 Бағыт: {category}\n🎯 Номинация: {nomination}\n📝 Сипаттама: {projectDesc}\n💬 Пікір: {comment}\n\nЖаңа өтініш беру үшін /start пайдаланыңыз.',
    status_active:
      '📊 Ағымдағы статус:\n\n👤 ТАӘ: {fullName}\n🎂 Жасы: {age}\n🏫 Сынып: {grade}\n🌆 Қала: {city}\n🏢 Оқу орны: {institution}\n👤 Жетекші: {supervisor}\n📞 Тел: {phone}\n🏆 Бағыт: {category}\n🎯 Номинация: {nomination}\n📋 Жоба: {projectTitle}\n🔗 Видео: {videoUrl}\n📎 Төлем: {payment}\n\n🔄 Ағымдағы қадам: {step}',
    lang_changed: '🌐 Тіл Қазақ тіліне өзгертілді',
    support_contact:
      '❌ Қате орын алды. Қайталап көріңіз немесе техникалық қолдауға жазыңыз: {supportHandle}',
    stuck_footer:
      '\n\n⸻\n❓ Сұрақтар туындаса: {supportHandle}\n🔄 Басынан бастау үшін: /cancel',

    select_contest: '📌 Қатысқыңыз келетін байқауды таңдаңыз:',
    start_submission_button: '🚀 ӨТІНІМ ЖІБЕРУ',
    back_to_contests_button: '⬅️ Артқа',
    back_button: '⬅️ Артқа',

    section1_header: '📋 1-БӨЛІМ: ҚАТЫСУШЫ ТУРАЛЫ АҚПАРАТ',

    step_full_name:
      '📋 1-БӨЛІМ: ҚАТЫСУШЫ ТУРАЛЫ АҚПАРАТ\n\n1️⃣ Баланың аты-жөнін енгізіңіз:',
    step_age: '2️⃣ Жасы (жыл):',
    step_grade: '3️⃣ Сыныбы/тобы:',
    step_city: '4️⃣ Қаласы/облысы:',
    step_institution:
      '5️⃣ Оқу орны (мектеп/балабақша/орталық атауын толық жазыңыз):',
    step_supervisor: '6️⃣ Жетекшінің аты-жөні:',
    step_phone: '7️⃣ Байланыс телефоны (WhatsApp):',

    section2_header: '🏆 2-БӨЛІМ: БАЙҚАУ ТУРАЛЫ',

    step_category:
      '🏆 2-БӨЛІМ: БАЙҚАУ ТУРАЛЫ\n\n8️⃣ Қай бағытқа қатысасыз? Төмендегі батырмаларды пайдаланып таңдаңыз:',
    category_junior: '🟢 JUNIOR (4–6 жас)',
    category_beginner: '🔵 BEGINNER (7–9 жас)',
    category_intermediate: '🟡 INTERMEDIATE (10–12 жас)',
    category_advanced: '🔴 ADVANCED (13–15 жас)',

    step_nomination: '9️⃣ Номинацияны таңдаңыз:',
    nomination_obstacle: '🤖 Кедергіден өтетін робот',
    nomination_smart: '💡 Ақылды робот жобасы',
    nomination_startup: '🚀 Инновациялық стартап жоба',

    step_project_title: '1️⃣0️⃣ Жоба атауын енгізіңіз:',
    step_project_desc:
      '1️⃣1️⃣ Жобаңыздың қысқаша сипаттамасын жазыңыз (2–3 сөйлем):',

    // ── SECTION 3: Work Submission ───────────────────────────────
    step_video:
      '🎥 3-БӨЛІМ: ЖҰМЫС ҚАБЫЛДАУ\n\n1️⃣2️⃣ Жобаңыздың видеосын Google Drive немесе YouTube-қа жүктеп, ашық сілтемесін жіберіңіз:\n\n⚠️ Сілтеме «кез-келген адам қарай алатындай» ашық болуы тиіс.',
    step_work_photo:
      '📎 3-БӨЛІМ: ЖҰМЫСТЫ ЖІБЕРУ\n\n📸 Қатысушының жұмысын (фото) жіберіңіз:\n⚠️ Файл анық, сапалы болуы керек.',
    step_work_link:
      '📎 3-БӨЛІМ: ЖҰМЫСТЫ ЖІБЕРУ\n\n🔗 Бейнежазбаға (видео) сілтеме жіберіңіз.\n\n⚠️ Бейнежазбаны алдын ала Google Drive немесе Instagram-ға жүктеп, "кез келген адам көре алатындай" (доступно всем) етіп ашып қойыңыз және сол сілтемені жіберіңіз.',

    // ── SECTION 4: Payment ───────────────────────────────────────
    step_payment:
      '💳 4-БӨЛІМ: ҚАТЫСУ ЖАРНАСЫ\n\n1️⃣3️⃣ Қатысу жарнасы: *1990 тг* (ерікті түрде)\n\nТөлем жасау үшін төмендегі сілтемені басыңыз:\n👉 https://pay.kaspi.kz/pay/aju6h4mi\n\nТөлем жасаған соң чек/скриншотты PDF форматында осы жерге жүктеңіз.\n\n⚠️ Чек PDF форматта болмаса, өтініш толық қабылданбайды.',
    step_payment_after_doc:
      '📎 Төлемді растау\n\nТөлем жасағаннан кейін:\n📌 Чекті PDF форматында осы чатқа жүктеңіз.\n(Файл ретінде жіберіңіз, фото емес.)\n\n⚠️ Чек PDF форматта болмаса, өтініш толық қабылданбайды.',

    // ── Confirmation ─────────────────────────────────────────────
    confirm_check_name:
      '🔁 Растау сұрағы:\n\nАты-жөндеріңізді қайта тексердіңіз бе?\n\n👤 Аты-жөні: *{fullName}*\n🎂 Жасы: {age}\n🏫 Сынып: {grade}\n🌆 Қала: {city}\n🏢 Оқу орны: {institution}\n👤 Жетекші: {supervisor}\n📞 Телефон: {phone}\n🏆 Бағыт: {category}\n🎯 Номинация: {nomination}\n📋 Жоба: {projectTitle}\n📝 Сипаттама: {projectDesc}\n🔗 Видео: {videoUrl}\n📎 Төлем: {payment}',
    confirm_yes_button: '✅ ИӘ, бәрі дұрыс',
    confirm_no_button: '✏️ ЖОҚ, өзгерту керек',
    confirm_edit_prompt: '🔄 Қайтадан дұрыс нұсқасын енгізіңіз.',

    confirm_summary:
      '✅ Енгізілген деректерді тексеріңіз:\n\n👤 ТАӘ: {fullName}\n🎂 Жасы: {age}\n🏫 Сыныбы: {grade}\n🌆 Қала: {city}\n🏢 Оқу орны: {institution}\n👤 Жетекші: {supervisor}\n📞 Байланыс: {phone}\n🏆 Бағыт: {category}\n🎯 Номинация: {nomination}\n📋 Жоба атауы: {projectTitle}\n📝 Сипаттама: {projectDesc}\n🔗 Видео: {videoUrl}\n📎 Төлем: {payment}\n\nБәрі дұрыс па?',
    confirm_button: '✅ Растау',
    edit_button: '✏️ Өңдеу',
    cancel_button: '❌ Болдырмау',

    // Success
    success:
      '✅ *Өтінішіңіз қабылданды!*\n\n📅 *Жұмыстар қабылдау:* 10-27 наурыз\n📢 *Нәтижелер:* 30-31 наурыз',
    confirmation_received:
      'Өтінім жібергеннен кейін растау ха хабарламасы келеді ✅',
    multiple_participation: '🎓 Әр байқауға бөлек қатысуға болады.',
    submission_comment: '💬 Сіздің өтінішіңізге пікір қалдырылды:\n\n{comment}',

    // Validation errors
    error_invalid_format: '❌ Форматы қате. Қайталап көріңіз:',
    error_invalid_age:
      '❌ Жасты дұрыс енгізіңіз. Тек сан болуы керек (мысалы: 8):',
    error_pdf_only: '❌ Қате! Төлем чегі тек PDF форматында болуы керек.',
    error_photo_only: '❌ Қате! Жұмысты Фото ретінде жіберіңіз.',
    error_url_required:
      '❌ Қате! Бейнежазба байқауы үшін тек сілтеме қабылданады. Оны Google Drive немесе YouTube-қа жүктеп, сілтемесін жіберіңіз.',
    error_phone_format:
      '❌ Телефон нөмірінің форматы қате. Мысалы: +7 707 123 45 67',
    error_upload_failed: '❌ Файлды жүктеу қатесі. Қайталап көріңіз.',
    error_pdf_size_exceeded:
      '❌ Файл көлемі 1 МБ-дан аспауы керек. Егер файл үлкен болса, оны Google Drive-қа жүктеп, сілтемесін жіберіңіз.',
    error_work_size_exceeded:
      '❌ Жұмыс көлемі 1 МБ-дан аспауы керек. Егер файл үлкен болса, оны Google Drive немесе Instagram-ға жүктеп, сілтемесін жіберіңіз.',
    error_payment_size_exceeded:
      '❌ Сіз төлем чегін жіберіп жатқан жоқсыз, файлды тексеріңіз (макс. 500 КБ).',
    error_no_video:
      '❌ Бейнежазбаларды (видео) тікелей жүктеуге болмайды. Сілтеме жіберіңіз.',
    error_name_format:
      '❌ Аты-жөніңізді дұрыс енгізіңіз (кем дегенде 2 сөз, тек әріптер):',
    error_use_buttons: '⚠️ Төмендегі батырмаларды пайдаланып таңдаңыз:',
    error_text_only: '⚠️ Өтініш, тек мәтін түрінде жауап беріңіз:',
    error_file_size: '❌ Қате! Файл өлшемі {maxSize} МБ аспауы керек.',
    error_file_type:
      '❌ Қате! Файл форматы жарамсыз (тек PDF, JPG, PNG рұқсат етіледі).',
    error_url_format: '❌ Жарамды сілтеме (URL) жіберіңіз.',
    error_url_telegram: '❌ Telegram сілтемелерін қолдануға болмайды.',
    error_select_contest_first:
      '⚠️ Жалғастыру үшін алдымен төмендегі батырмалар арқылы байқауды таңдаңыз:',

    // Placeholders
    placeholder_not_set: 'Көрсетілмеген',
    placeholder_step_select_contest: 'Байқау таңдау',
    placeholder_step_full_name: 'ТАӘ енгізу',
    placeholder_step_age: 'Жасы',
    placeholder_step_grade: 'Сынып',
    placeholder_step_institution: 'Оқу орны',
    placeholder_step_city: 'Қала/облыс',
    placeholder_step_supervisor: 'Жетекші',
    placeholder_step_phone: 'Телефон',
    placeholder_step_category: 'Бағыт таңдау',
    placeholder_step_nomination: 'Номинация таңдау',
    placeholder_step_project_title: 'Жоба атауы',
    placeholder_step_project_desc: 'Жобаның сипаттамасы',
    placeholder_step_video: 'Видео сілтемесі',
    placeholder_step_work: 'Жұмыс',
    placeholder_step_payment: 'Төлем',
    placeholder_step_payment_confirm: 'Төлем растауын күту',
    placeholder_step_confirm: 'Растау',

    // Help
    help: '📖 Бот нұсқаулығы:\n\n/start — Бастау\n/cancel — Тоқтату\n/status — Күй\n/help — Анықтама',
  },
};

const MADENIET_MESSAGES: Record<Language, MessageSchema> = {
  kz: {
    ...ROBOSTART_MESSAGES.kz,
    start_header:
      '📘 «MADENIET_EDUCATION» республикалық балалар мен жасөспірімдердің оқу-ғылыми шығармашылық журналына 2026 жылдың 15 наурызы – 25 наурызы аралығында жұмыстарыңызды жолдай аласыздар.\n\n⏱️Байқау жұмыстарын қабылдау 25 наурыз 21.00 ге дейін жалғасады.\n\n📝 Байқау нәтижесі барлық өтініштер қабылданғаннан соң, сараптамадан өтіп шығады.\nҚортынды шыққан соң өтініш берген байланыс нөмеріне дипломдар жолданады.',

    last_submission_info:
      '📊 Соңғы өтінішіңіздің статусы (№{regNumber}):\n\n👤 ТАӘ: {fullName}\n💬 Пікір: {comment}\n\nЖаңа өтініш беру үшін /start пайдаланыңыз.',

    status_active:
      '📊 Ағымдағы статус:\n\n👤 ТАӘ: {fullName}\n🎂 Жасы: {age}\n🏫 Сынып: {grade}\n🌆 Қала: {city}\n🏢 Оқу орны: {institution}\n👤 Жетекші: {supervisor}\n📞 Тел: {phone}\n🏆 Бағыт: {category}\n🎯 Номинация: {nomination}\n📎 Төлем: {payment}\n\n🔄 Ағымдағы қадам: {step}',

    confirm_check_name:
      '🔁 Растау сұрағы:\n\nАты-жөндеріңізді қайта тексердіңіз бе?\n\n👤 Аты-жөні: *{fullName}*\n🎂 Жасы: {age}\n🏫 Сынып: {grade}\n🌆 Қала: {city}\n🏢 Оқу орны: {institution}\n👤 Жетекші: {supervisor}\n📞 Телефон: {phone}\n🏆 Бағыт: {category}\n🎯 Номинация: {nomination}\n📎 Төлем: {payment}',

    confirm_summary:
      '✅ Енгізілген деректерді тексеріңіз:\n\n👤 ТАӘ: {fullName}\n🎂 Жасы: {age}\n🏫 Сыныбы: {grade}\n🌆 Қала: {city}\n🏢 Оқу орны: {institution}\n👤 Жетекші: {supervisor}\n📞 Байланыс: {phone}\n🏆 Бағыт: {category}\n🎯 Номинация: {nomination}\n📎 Төлем: {payment}\n\nБәрі дұрыс па?',

    success:
      '✅ *Өтінішіңіз қабылданды!*\n\n📝 Байқау нәтижесі барлық өтініштер қабылданғаннан соң шығады.',

    step_category:
      '8️⃣ Қай бағытқа қатысасыз? Төмендегі батырмаларды пайдаланып таңдаңыз:',
    madeniet_category_shuaqty: '“ШУАҚТЫ КҮНДЕР”',
    madeniet_category_nauryz: '“ӘЗ НАУРЫЗЫМ- ЖАҢА ЖЫЛЫМ”',

    step_nomination:
      '9️⃣ Қатысу жарнасының түрін таңдаңыз:\n\n🖇️ 1190 тг — Баланың дипломы, жетекшінің дипломы, ата-ананың дипломы электронды түрде жолданады.\n\n🖇️ 5990 тг — Қатысушының дипломдары, мойнына медаль, дамыту ойыншығы Қазпочта қызметімен сіздің адреске жолданады.\n\n✍️ 9990 тг — Балаға медаль + кубок + ойыншық + қатысушы мен жетекші дипломы Қазпочта арқылы жіберіледі.',

    madeniet_nomination_1190: '🖇️ 1190 тг',
    madeniet_nomination_5990: '🖇️ 5990 тг',
    madeniet_nomination_9990: '✍️ 9990 тг',

    step_work_photo:
      '📎 10-БӨЛІМ: ЖҰМЫСТЫ ЖІБЕРУ\n\n🔟 Қатысушының жұмысын (фото/сурет) жіберіңіз:\n⚠️ Файл анық, сапалы болуы керек.',

    step_payment:
      '💳 11-БӨЛІМ: ҚАТЫСУ ЖАРНАСЫ\n\n1️⃣1️⃣ Төлем жасап, чекті PDF форматында жүктеңіз:\n\nТөлем жасау: https://pay.kaspi.kz/pay/aju6h4mi\n\n⚠️ Төлем жасаған соң чек/скриншотты PDF форматында осы жерге жүктеңіз. Чек PDF форматта болмаса, өтініш толық қабылданбайды.',

    placeholder_step_work: 'Жұмыс (Фото)',
    placeholder_step_payment: 'Төлем',
  },
};

// Map of bot slugs to their message configurations
export const BOT_MESSAGES: Record<string, Record<Language, MessageSchema>> = {
  olympiad_bot: ROBOSTART_MESSAGES,
  creative_bot: ROBOSTART_MESSAGES,
  madeniet_bot: MADENIET_MESSAGES,
  default: ROBOSTART_MESSAGES,
};

// Fallback for direct export (if needed by other services)
export const MESSAGES = ROBOSTART_MESSAGES;
