import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { PrismaService } from '../../database/prisma.service';
import { Bot } from '@prisma/client';

@Injectable()
export class BotRegistryService implements OnModuleInit {
  private readonly logger = new Logger(BotRegistryService.name);
  private tokenToBot = new Map<string, Bot>();

  constructor(private readonly prisma: PrismaService) {}

  async onModuleInit() {
    await this.refreshCache();
  }

  async refreshCache() {
    const bots = await this.prisma.bot.findMany({
      where: { isActive: true },
    });
    this.tokenToBot.clear();
    for (const bot of bots) {
      this.tokenToBot.set(bot.token, bot);
    }
    this.logger.log(`Bot cache refreshed: ${this.tokenToBot.size} bots active`);
  }

  getBot(token: string): Bot | undefined {
    return this.tokenToBot.get(token);
  }

  getBotId(token: string): string | undefined {
    return this.tokenToBot.get(token)?.id;
  }

  async getAllActiveTokens(): Promise<string[]> {
    const bots = await this.prisma.bot.findMany({
      where: { isActive: true },
      select: { token: true },
    });
    return bots.map((b) => b.token);
  }
}
