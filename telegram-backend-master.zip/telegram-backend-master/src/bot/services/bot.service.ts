import { Injectable, Logger } from '@nestjs/common';
import { InjectBot } from 'nestjs-telegraf';
import { Telegraf, Context } from 'telegraf';

@Injectable()
export class BotService {
  private readonly logger = new Logger(BotService.name);

  constructor(
    @InjectBot() private readonly roboBot: Telegraf<Context>,
    @InjectBot('MADENIET_BOT') private readonly madenietBot: Telegraf<Context>,
  ) {}
  
  private getBot(botSlug?: string): Telegraf<Context> {
    if (botSlug?.includes('madeniet')) {
      return this.madenietBot;
    }
    return this.roboBot;
  }

  /**
   * Send a document (PDF, etc.) to a user by their Telegram ID
   */
  async sendDocument(
    telegramUserId: string | number | bigint,
    file: Buffer,
    fileName: string,
    caption?: string,
    botSlug?: string,
  ) {
    try {
      const bot = this.getBot(botSlug);
      await bot.telegram.sendDocument(
        Number(telegramUserId),
        {
          source: file,
          filename: fileName,
        },
        {
          caption,
        },
      );
      return true;
    } catch (error) {
      this.logger.error(
        `Failed to send document to ${telegramUserId} via ${botSlug || 'default'}: ${error.message}`,
      );
      throw error;
    }
  }

  /**
   * Send a simple text message to a user
   */
  async sendMessage(
    telegramUserId: string | number | bigint,
    text: string,
    botSlug?: string,
  ) {
    try {
      const bot = this.getBot(botSlug);
      await bot.telegram.sendMessage(Number(telegramUserId), text);
      return true;
    } catch (error) {
      this.logger.error(
        `Failed to send message to ${telegramUserId} via ${botSlug || 'default'}: ${error.message}`,
      );
      throw error;
    }
  }
}
