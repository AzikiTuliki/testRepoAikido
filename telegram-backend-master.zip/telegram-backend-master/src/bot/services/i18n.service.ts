import { Injectable } from '@nestjs/common';
import { MESSAGES, Language, BOT_MESSAGES } from '../constants/messages';

@Injectable()
export class I18nService {
  /**
   * Translate key with optional parameters
   */
  t(
    key: string,
    lang: Language = 'kz',
    params?: Record<string, string>,
    botSlug?: string,
    appendFooter: boolean = false,
  ): string {
    const config = (BOT_MESSAGES as any)[botSlug || 'default'] || MESSAGES;
    const supportHandle: string =
      (config as any).support_handle || '@AisMazhen';

    let message: string = config[lang]?.[key] || config['kz']?.[key] || key;

    // Replace placeholders in the main message
    const finalParams: Record<string, string> = {
      ...(params || {}),
      supportHandle,
    };

    Object.entries(finalParams).forEach(([param, value]) => {
      message = message.replace(new RegExp(`{${param}}`, 'g'), value);
    });

    // Append footer if requested
    if (appendFooter) {
      let footer =
        config[lang]?.stuck_footer || config['kz']?.stuck_footer || '';
      Object.entries(finalParams).forEach(([param, value]) => {
        footer = footer.replace(new RegExp(`{${param}}`, 'g'), value);
      });
      message += footer;
    }

    return message;
  }
}
