import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { BotState } from '../constants/states.enum';
import { Language } from '../constants/messages';

export interface UserState {
  telegramUserId: number;
  username?: string;
  language: Language;
  step: BotState;
  contestId?: string;
  botId: string;
  draftData: {
    // Section 1: Participant Info
    fullName?: string;
    age?: string;
    grade?: string;
    institution?: string;
    city?: string;
    supervisor?: string;
    phone?: string;
    // Section 2: Contest Info
    category?: string;
    nomination?: string;
    projectTitle?: string;
    projectDesc?: string;
    // Section 3: Work
    videoUrl?: string;
    workUrl?: string;
  };
  workFile?: {
    fileId: string;
    fileName: string;
    mimeType: string;
    sizeBytes: number;
  };
  paymentFile?: {
    fileId: string;
    fileName: string;
    mimeType: string;
    sizeBytes: number;
  };
  editingField?:
    | 'fullName'
    | 'age'
    | 'grade'
    | 'institution'
    | 'city'
    | 'supervisor'
    | 'phone'
    | 'category'
    | 'nomination'
    | 'projectTitle'
    | 'projectDesc'
    | 'videoUrl'
    | 'work'
    | 'payment';
  updatedAt: number;
}
@Injectable()
export class StateService {
  private readonly logger = new Logger(StateService.name);
  private readonly sessions = new Map<string, UserState>(); // Key: botId_userId
  private readonly ttlMs: number;

  constructor(private readonly configService: ConfigService) {
    const ttlHours =
      this.configService.get<number>('app.sessionTtlHours') ?? 24;
    this.ttlMs = ttlHours * 60 * 60 * 1000;

    // Clean up expired sessions every hour
    setInterval(() => this.cleanupExpiredSessions(), 60 * 60 * 1000);
  }

  private cleanupExpiredSessions() {
    const now = Date.now();
    let cleaned = 0;

    for (const [key, state] of this.sessions.entries()) {
      if (now - state.updatedAt > this.ttlMs) {
        this.sessions.delete(key);
        cleaned++;
      }
    }

    if (cleaned > 0) {
      this.logger.log(`Cleaned up ${cleaned} expired sessions`);
    }
  }

  /**
   * Get user state from memory
   */
  getState(userId: number, botId: string): UserState | null {
    const key = `${botId}_${userId}`;
    const state = this.sessions.get(key);

    if (!state) return null;

    // Check if expired
    if (Date.now() - state.updatedAt > this.ttlMs) {
      this.sessions.delete(key);
      return null;
    }

    return state;
  }

  /**
   * Set user state in memory
   */
  setState(userId: number, botId: string, state: Partial<UserState>): void {
    const key = `${botId}_${userId}`;
    const currentState = this.sessions.get(key);

    const newState: UserState = {
      telegramUserId: userId,
      botId,
      language: 'kz',
      step: BotState.IDLE,
      draftData: {},
      ...currentState,
      ...state,
      updatedAt: Date.now(),
    };

    this.sessions.set(key, newState);
  }

  /**
   * Update specific fields in user state
   */
  updateState(
    userId: number,
    botId: string,
    updates: Partial<UserState>,
  ): void {
    // Removed async as there's no await
    const key = `${botId}_${userId}`;
    const state = this.sessions.get(key);

    if (!state) {
      this.setState(userId, botId, updates);
      return;
    }

    // Merge updates
    const newState = {
      ...state,
      ...updates,
      draftData: {
        ...state.draftData,
        ...(updates.draftData || {}),
      },
      updatedAt: Date.now(),
    };

    this.sessions.set(key, newState);
  }

  /**
   * Clear user state
   */
  clearState(userId: number, botId: string): void {
    const key = `${botId}_${userId}`;
    this.sessions.delete(key);
    this.logger.log(`Cleared state for user ${userId} on bot ${botId}`);
  }

  /**
   * Initialize or reset state for a new session
   */
  initializeState(
    userId: number,
    botId: string,
    username?: string,
    language: Language = 'kz',
  ): void {
    this.setState(userId, botId, {
      telegramUserId: userId,
      botId,
      username,
      language,
      step: BotState.SELECT_CONTEST,
      draftData: {},
      contestId: undefined,
      workFile: undefined,
      paymentFile: undefined,
      editingField: undefined,
    });
  }
}
