import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class ValidationService {
  private readonly allowTgUrls: boolean;
  private readonly maxFileSizeBytes: number;

  constructor(private readonly configService: ConfigService) {
    this.allowTgUrls =
      this.configService.get<boolean>('app.allowTgUrls') ?? false;
    const maxSizeMB = this.configService.get<number>('app.maxFileSizeMB') ?? 10;
    this.maxFileSizeBytes = maxSizeMB * 1024 * 1024;
  }

  /**
   * Validate full name (ФИО)
   * Requirements:
   * - At least 2 words
   * - Each word >= 2 characters
   * - Only Cyrillic/Latin letters, spaces, and hyphens
   */
  validateName(name: string): { valid: boolean; error?: string } {
    const trimmed = name.trim();

    // Check for emojis or numbers only
    if (!/[а-яёА-ЯЁa-zA-ZӘәҒғҚқҢңӨөҰұҮүҺһІі]/.test(trimmed)) {
      return { valid: false, error: 'error_name_format' };
    }

    // Split by spaces and filter empty strings
    const words = trimmed.split(/\s+/).filter((w) => w.length > 0);

    if (words.length < 2) {
      return { valid: false, error: 'error_name_format' };
    }

    // Check each word
    for (const word of words) {
      if (word.length < 2) {
        return { valid: false, error: 'error_name_format' };
      }

      // Only allow Cyrillic, Latin, and hyphens
      if (!/^[а-яёА-ЯЁa-zA-ZӘәҒғҚқҢңӨөҰұҮүҺһІі-]+$/.test(word)) {
        return { valid: false, error: 'error_name_format' };
      }
    }

    return { valid: true };
  }

  /**
   * Validate address
   * Requirements:
   * - Min 10 characters
   * - Must contain at least one letter
   * - No URLs
   */
  validateAddress(address: string): { valid: boolean; error?: string } {
    const trimmed = address.trim();

    if (trimmed.length < 10) {
      return { valid: false, error: 'error_address_format' };
    }

    // Must contain at least one letter
    if (!/[а-яёА-ЯЁa-zA-ZӘәҒғҚқҢңӨөҰұҮүҺһІі]/.test(trimmed)) {
      return { valid: false, error: 'error_address_format' };
    }

    // Check for URLs
    if (/https?:\/\//.test(trimmed) || /www\./i.test(trimmed)) {
      return { valid: false, error: 'error_address_format' };
    }

    return { valid: true };
  }

  /**
   * Validate URL
   * Requirements:
   * - Valid HTTP/HTTPS URL
   * - Optionally block Telegram URLs
   */
  validateUrl(url: string): { valid: boolean; error?: string } {
    const trimmed = url.trim();

    // Try to parse as URL
    let parsedUrl: URL;
    try {
      parsedUrl = new URL(trimmed);
    } catch {
      return { valid: false, error: 'error_url_format' };
    }

    // Must be HTTP or HTTPS
    if (!['http:', 'https:'].includes(parsedUrl.protocol)) {
      return { valid: false, error: 'error_url_format' };
    }

    // Check for Telegram URLs if not allowed
    if (!this.allowTgUrls) {
      const hostname = parsedUrl.hostname.toLowerCase();
      if (hostname.includes('t.me') || hostname.includes('telegram')) {
        return { valid: false, error: 'error_url_telegram' };
      }
    }

    return { valid: true };
  }

  /**
   * Validate file
   * Requirements:
   * - PDF, JPG, PNG only
   * - Max size from config
   */
  validateFile(
    mimeType: string,
    sizeBytes: number,
  ): { valid: boolean; error?: string; maxSizeMB?: number } {
    const allowedTypes = ['application/pdf', 'image/jpeg', 'image/png'];

    if (!allowedTypes.includes(mimeType.toLowerCase())) {
      return { valid: false, error: 'error_file_type' };
    }

    if (sizeBytes > this.maxFileSizeBytes) {
      return {
        valid: false,
        error: 'error_file_size',
        maxSizeMB: this.configService.get<number>('app.maxFileSizeMB'),
      };
    }

    return { valid: true };
  }

  /**
   * Generic simple text validation (institution, city, supervisor, etc.)
   * Requirements:
   * - Min 2 characters
   * - Must contain at least one letter
   */
  validateSimpleText(text: string): { valid: boolean; error?: string } {
    const trimmed = text.trim();
    if (trimmed.length < 2) {
      return { valid: false, error: 'error_invalid_format' };
    }
    // Must contain at least one letter (Cyrillic or Latin)
    if (!/[а-яёА-ЯЁa-zA-ZӘәҒғҚқҢңӨөҰұҮүҺһІі]/.test(trimmed)) {
      return { valid: false, error: 'error_invalid_format' };
    }
    return { valid: true };
  }

  /**
   * Validate grade/group
   * Requirements:
   * - At least 1 character
   * - Can be numeric or text
   */
  validateGrade(grade: string): { valid: boolean; error?: string } {
    const trimmed = grade.trim();
    if (trimmed.length < 1) {
      return { valid: false, error: 'error_invalid_format' };
    }
    return { valid: true };
  }

  /**
   * Validate Phone Number
   * Requirements:
   * - Must be a valid phone format
   * - Supports +7, 8, and local digits
   * - Allows spaces, hyphens, and parentheses
   */
  validatePhone(phone: string): { valid: boolean; error?: string } {
    const trimmed = phone.trim();

    // Minimum 10 digits after stripping non-digits
    const digitsOnly = trimmed.replace(/\D/g, '');

    if (digitsOnly.length < 10 || digitsOnly.length > 15) {
      return { valid: false, error: 'error_phone_format' };
    }

    // Basic regex checks for start digits if they look like KZ/RU numbers
    const phoneRegex =
      /^(\+?\d{1,3})?[-. (]*(\d{3})[-. )]*(\d{3})[-. ]*(\d{2})[-. ]*(\d{2})$/;
    const alternativeRegex = /^\+?\d{10,15}$/;

    if (!phoneRegex.test(trimmed) && !alternativeRegex.test(digitsOnly)) {
      return { valid: false, error: 'error_phone_format' };
    }

    return { valid: true };
  }
}
