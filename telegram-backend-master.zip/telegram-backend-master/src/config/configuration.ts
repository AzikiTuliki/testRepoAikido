export default () => ({
  nodeEnv: process.env.NODE_ENV || 'development',

  telegram: {
    botToken: process.env.ROBOT_TOKEN,
    madenietBotToken: process.env.MADENIET_TOKEN,
  },

  database: {
    url: process.env.DATABASE_URL,
  },

  minio: {
    endpoint: process.env.MINIO_ENDPOINT || 'localhost',
    port: parseInt(process.env.MINIO_PORT || '9000', 10),
    useSSL: process.env.MINIO_USE_SSL === 'true',
    accessKey: process.env.MINIO_ACCESS_KEY || 'minioadmin',
    secretKey: process.env.MINIO_SECRET_KEY || 'minioadmin',
    bucket: process.env.MINIO_BUCKET || 'telegram-bot-uploads',
    publicBaseUrl: process.env.MINIO_PUBLIC_BASE_URL,
  },

  app: {
    allowTgUrls: process.env.ALLOW_TG_URLS === 'true',
    maxFileSizeMB: parseInt(process.env.MAX_FILE_SIZE_MB || '5', 10),
    sessionTtlHours: parseInt(process.env.SESSION_TTL_HOURS || '24', 10),
  },

  auth: {
    jwtSecret: process.env.JWT_SECRET || 'super-secret',
    refreshTokenSecret: process.env.REFRESH_TOKEN_SECRET || 'refresh-secret',
  },
});
