import { Module, Global } from '@nestjs/common';
import { PrismaService } from './prisma.service';
import { SubmissionRepository } from './repositories/submission.repository';
import { ContestRepository } from './repositories/contest.repository';

@Global()
@Module({
  providers: [PrismaService, SubmissionRepository, ContestRepository],
  exports: [PrismaService, SubmissionRepository, ContestRepository],
})
export class DatabaseModule {}
