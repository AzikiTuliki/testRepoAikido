import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma.service';
import { Contest, WorkFormat } from '@prisma/client';

@Injectable()
export class ContestRepository {
  constructor(private readonly prisma: PrismaService) {}

  async findAll(botId?: string): Promise<Contest[]> {
    return this.prisma.contest.findMany({
      where: botId ? { botId } : {},
      orderBy: { order: 'asc' },
      include: { bot: true },
    });
  }

  async findAllActive(botId: string): Promise<Contest[]> {
    return this.prisma.contest.findMany({
      where: { isActive: true, botId },
      orderBy: { order: 'asc' },
    });
  }

  async findById(id: string): Promise<Contest | null> {
    if (!id) return null;
    return this.prisma.contest.findUnique({
      where: { id },
    });
  }

  async create(data: {
    name?: string;
    description?: string;
    isActive?: boolean;
    order?: number;
    workFormat?: WorkFormat;
    botId: string;
  }): Promise<Contest> {
    return this.prisma.contest.create({
      data,
    });
  }

  async update(
    id: string,
    data: {
      name?: string;
      description?: string;
      isActive?: boolean;
      order?: number;
      workFormat?: WorkFormat;
      botId?: string;
    },
  ): Promise<Contest> {
    return this.prisma.contest.update({
      where: { id },
      data,
    });
  }

  async delete(id: string): Promise<Contest> {
    return this.prisma.contest.delete({
      where: { id },
    });
  }
}
