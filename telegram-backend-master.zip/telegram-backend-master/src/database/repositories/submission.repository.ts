import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma.service';
import { Prisma, Submission } from '@prisma/client';

export interface CreateSubmissionDto {
  telegramUserId: bigint;
  username?: string;
  language: string;
  contestId: string;
  botId: string;

  // Participant Data (Section 1)
  fullName: string;
  age?: string;
  institution: string;
  grade: string;
  city?: string;
  supervisor: string;
  phone: string;

  // Contest Data (Section 2)
  category?: string;
  nomination?: string;
  projectTitle?: string;
  projectDesc?: string;

  // Work Data (Section 3)
  videoUrl?: string;
  workUrl?: string;
  workFileId?: string;
  workFileName?: string;

  // Payment Data (Section 4)
  paymentFileId: string;
  paymentFileName: string;
  paymentObjectKey: string;
}

@Injectable()
export class SubmissionRepository {
  constructor(private readonly prisma: PrismaService) {}

  async create(data: CreateSubmissionDto): Promise<Submission> {
    const { ...rest } = data;
    return this.prisma.submission.create({
      data: {
        ...rest,
      },
    });
  }

  async findByTelegramUserId(telegramUserId: bigint): Promise<Submission[]> {
    return this.prisma.submission.findMany({
      where: { telegramUserId },
      orderBy: { createdAt: 'desc' },
    });
  }

  async findById(id: string): Promise<(Submission & { contest: any }) | null> {
    return this.prisma.submission.findUnique({
      where: { id },
      include: {
        contest: {
          include: { bot: true },
        },
      },
    }) as any;
  }

  async findAll(params: {
    skip?: number;
    take?: number;
    search?: string;
    contestId?: string;
    botId?: string;
    language?: string;
  }): Promise<{ items: Submission[]; total: number }> {
    const { skip, take, search, contestId, botId, language } = params;

    const where: Prisma.SubmissionWhereInput = {};

    if (contestId) {
      where.contestId = contestId;
    }

    if (botId) {
      where.botId = botId;
    }

    if (language) {
      where.language = language;
    }

    if (search) {
      where.OR = [
        { fullName: { contains: search, mode: 'insensitive' } },
        { supervisor: { contains: search, mode: 'insensitive' } },
        { phone: { contains: search, mode: 'insensitive' } },
        { institution: { contains: search, mode: 'insensitive' } },
        { username: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [items, total] = await Promise.all([
      this.prisma.submission.findMany({
        where,
        skip,
        take,
        orderBy: { createdAt: 'desc' },
        include: { contest: true },
      }),
      this.prisma.submission.count({ where }),
    ]);

    return { items, total };
  }

  async update(id: string, data: Partial<Submission>): Promise<Submission> {
    return this.prisma.submission.update({
      where: { id },
      data,
    });
  }

  async delete(id: string): Promise<Submission> {
    return this.prisma.submission.delete({
      where: { id },
    });
  }
}
