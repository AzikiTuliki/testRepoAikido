import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { Logger, ValidationPipe } from '@nestjs/common';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import helmet from 'helmet';
import { rateLimit } from 'express-rate-limit';

async function bootstrap() {
  const logger = new Logger('Bootstrap');

  const app = await NestFactory.create(AppModule);

  // Security: Enable Helmet to set various HTTP headers for security
  app.use(helmet());

  // Security: Enable 'trust proxy' for express-rate-limit
  app.getHttpAdapter().getInstance().set('trust proxy', 1);

  // Security: Enable Rate Limiting to prevent brute-force attacks
  app.use(
    rateLimit({
      windowMs: 15 * 60 * 1000, // 15 minutes
      max: 100, // limit each IP to 100 requests per windowMs
      message: 'Too many requests from this IP, please try again after 15 minutes',
      standardHeaders: true, // Return rate limit info in the `RateLimit-*` headers
      legacyHeaders: false, // Disable the `X-RateLimit-*` headers
    }),
  );

  // Global Validation: Ensure all incoming data is validated against DTOs
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true, // Strip properties that do not have any decorators in the DTO
      forbidNonWhitelisted: false, // Don't throw errors for extra fields (like ID or timestamps)
      transform: true, // Automatically transform payloads to be objects typed according to their DTO classes
    }),
  );

  // Serialize BigInt to string for JSON responses
  (BigInt.prototype as any).toJSON = function (this: bigint) {
    return this.toString();
  };

  // Enable CORS with specific origin in production
  app.enableCors({
    origin: process.env.ALLOWED_ORIGINS
      ? process.env.ALLOWED_ORIGINS.split(',')
      : '*',
    methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
    credentials: true,
  });

  // Enable graceful shutdown
  app.enableShutdownHooks();

  const port = process.env.PORT || 8080;

  // Setup Swagger only in development
  if (process.env.NODE_ENV !== 'production') {
    const config = new DocumentBuilder()
      .setTitle('Telegram Bot API')
      .setDescription('API documentation for the Telegram Bot backend')
      .setVersion('1.0')
      .addBearerAuth()
      .build();
    const document = SwaggerModule.createDocument(app, config);
    SwaggerModule.setup('api/docs', app, document);
    logger.log(
      `📄 Swagger documentation available at http://localhost:${port}/api/docs`,
    );
  }

  await app.listen(port);

  logger.log(`🤖 Telegram bot is running`);
  logger.log(`🌐 Application listening on port ${port}`);
}

bootstrap();
