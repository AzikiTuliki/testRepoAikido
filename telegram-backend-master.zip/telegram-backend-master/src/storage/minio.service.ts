import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import {
  S3Client,
  PutObjectCommand,
  GetObjectCommand,
  HeadBucketCommand,
  CreateBucketCommand,
  DeleteObjectCommand,
  DeleteObjectsCommand,
} from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { Readable } from 'stream';

export interface UploadFileResult {
  bucket: string;
  objectKey: string;
  url?: string;
}

@Injectable()
export class MinioService implements OnModuleInit {
  private readonly logger = new Logger(MinioService.name);
  private s3Client: S3Client;
  private bucket: string;
  private publicBaseUrl?: string;

  constructor(private readonly configService: ConfigService) {
    const endpoint =
      this.configService.get<string>('minio.endpoint') || 'localhost';
    const port = this.configService.get<number>('minio.port') || 9000;
    const useSSL = this.configService.get<boolean>('minio.useSSL') || false;
    const accessKey =
      this.configService.get<string>('minio.accessKey') || 'minioadmin';
    const secretKey =
      this.configService.get<string>('minio.secretKey') || 'minioadmin';

    this.bucket =
      this.configService.get<string>('minio.bucket') || 'telegram-bot-uploads';
    this.publicBaseUrl = this.configService.get<string>('minio.publicBaseUrl');

    const protocol = useSSL ? 'https' : 'http';
    const endpointUrl = `${protocol}://${endpoint}:${port}`;

    this.s3Client = new S3Client({
      endpoint: endpointUrl,
      region: 'us-east-1', // MinIO doesn't use regions, but SDK requires it
      credentials: {
        accessKeyId: accessKey,
        secretAccessKey: secretKey,
      },
      forcePathStyle: true, // Required for MinIO
    });
  }

  async onModuleInit() {
    await this.ensureBucketExists();
  }

  private async ensureBucketExists(): Promise<void> {
    try {
      await this.s3Client.send(new HeadBucketCommand({ Bucket: this.bucket }));
      this.logger.log(`Bucket "${this.bucket}" exists`);
    } catch (error: unknown) {
      if (error instanceof Error && error.name === 'NotFound') {
        this.logger.log(`Creating bucket "${this.bucket}"...`);
        await this.s3Client.send(
          new CreateBucketCommand({ Bucket: this.bucket }),
        );
        this.logger.log(`Bucket "${this.bucket}" created successfully`);
      } else {
        const message = error instanceof Error ? error.message : String(error);
        this.logger.error(`Error checking bucket: ${message}`);
        throw error;
      }
    }
  }

  /**
   * Upload a file stream to MinIO
   * @param objectKey - The key/path for the object in the bucket
   * @param stream - Readable stream of the file data
   * @param mimeType - MIME type of the file
   * @param sizeBytes - Size of the file in bytes
   */
  async uploadFile(
    objectKey: string,
    stream: Readable,
    mimeType: string,
    sizeBytes: number,
  ): Promise<UploadFileResult> {
    try {
      // Convert stream to buffer for upload
      const chunks: Buffer[] = [];
      for await (const chunk of stream) {
        chunks.push(Buffer.from(chunk));
      }
      const buffer = Buffer.concat(chunks);

      const command = new PutObjectCommand({
        Bucket: this.bucket,
        Key: objectKey,
        Body: buffer,
        ContentType: mimeType,
        ContentLength: sizeBytes,
      });

      await this.s3Client.send(command);

      this.logger.log(`File uploaded successfully: ${objectKey}`);

      // Generate URL
      let url: string | undefined;
      if (this.publicBaseUrl) {
        // Public bucket - construct direct URL
        const separator = this.publicBaseUrl.endsWith('/') ? '' : '/';
        url = `${this.publicBaseUrl}${separator}${objectKey}`;
      }
      // For private buckets, we'll generate presigned URLs on-demand

      return {
        bucket: this.bucket,
        objectKey,
        url,
      };
    } catch (error: unknown) {
      const message = error instanceof Error ? error.message : String(error);
      this.logger.error(`Error uploading file: ${message}`);
      throw error;
    }
  }

  /**
   * Generate a presigned GET URL for a private object (valid for 15 minutes)
   * If a public base URL is configured, it returns a direct URL.
   */
  async generatePresignedUrl(objectKey: string): Promise<string> {
    // If public base URL is configured, use it instead of generating a presigned URL
    if (this.publicBaseUrl) {
      const separator = this.publicBaseUrl.endsWith('/') ? '' : '/';
      return `${this.publicBaseUrl}${separator}${objectKey}`;
    }

    const command = new GetObjectCommand({
      Bucket: this.bucket,
      Key: objectKey,
    });

    const url = await getSignedUrl(this.s3Client, command, {
      expiresIn: 15 * 60, // 15 minutes
    });

    return url;
  }

  /**
   * Delete a single file from MinIO
   */
  async deleteFile(objectKey: string): Promise<void> {
    try {
      await this.s3Client.send(
        new DeleteObjectCommand({
          Bucket: this.bucket,
          Key: objectKey,
        }),
      );
      this.logger.log(`File deleted successfully: ${objectKey}`);
    } catch (error: unknown) {
      const message = error instanceof Error ? error.message : String(error);
      this.logger.error(`Error deleting file: ${message}`);
    }
  }

  /**
   * Delete multiple files from MinIO efficiently
   */
  async deleteMultipleFiles(objectKeys: string[]): Promise<void> {
    if (objectKeys.length === 0) return;

    try {
      await this.s3Client.send(
        new DeleteObjectsCommand({
          Bucket: this.bucket,
          Delete: {
            Objects: objectKeys.map((key) => ({ Key: key })),
          },
        }),
      );
      this.logger.log(`Successfully deleted ${objectKeys.length} files`);
    } catch (error: unknown) {
      const message = error instanceof Error ? error.message : String(error);
      this.logger.error(`Error deleting multiple files: ${message}`);
    }
  }
}
